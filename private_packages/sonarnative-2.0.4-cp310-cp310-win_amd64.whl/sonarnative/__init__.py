from . _sonarnative import *

def pure_python():
    pass