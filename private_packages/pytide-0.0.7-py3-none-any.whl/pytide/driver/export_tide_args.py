from typing import NamedTuple, Optional

import numpy as np


class ExportTideArgs(NamedTuple):
    """
    Class representing all arguments for configuring the process
    """

    # Path of Ttb file to create
    o_path: str

    # Mandatory layers
    time: np.ndarray[np.uint64]  # in nanoseconds since 1970-01-01T00:00:00Z
    tide: np.ndarray

    # Optional layers
    latitude: Optional[np.ndarray] = None
    longitude: Optional[np.ndarray] = None
    metadata: dict[str, str] = {}

    overwrite: bool = False
