#! /usr/bin/env python3
# coding: utf-8

import logging
import os
from typing import Callable

import numpy as np

from pytide.driver.export_tide_args import ExportTideArgs
from pytide.driver.tide_netcdf import tide_netcdf_driver

__logger = logging.getLogger("Export Tide Netcdf")

# pylint: disable=unsupported-binary-operation


def exports(**kwargs) -> None:
    """
    Function accepting all arguments of the process as a dict. Possible arguments are listed in "ExportTideArgs" class
    """
    exports_with_ExportTideArgs(ExportTideArgs(**kwargs))


def exports_with_ExportTideArgs(args: ExportTideArgs) -> None:
    """
    Main function
    Use arguments to create a TTB file
    """
    if not os.path.exists(args.o_path) or args.overwrite:
        _process_export(args)
    else:
        __logger.warning(f"{args.o_path} exists and cannot be overwritten")


def _process_export(args: ExportTideArgs) -> None:
    __logger.info(f"Exporting {args.o_path} ")

    with tide_netcdf_driver.nc_open(args.o_path, "w") as o_tide_netcdf:
        # Mandatory variables
        _creates_variable(o_tide_netcdf.create_time_var, args.time)
        _creates_variable(o_tide_netcdf.create_latitude_var, args.latitude)
        _creates_variable(o_tide_netcdf.create_longitude_var, args.longitude)
        _creates_variable(o_tide_netcdf.create_tide_var, args.tide)
        # Global attributes
        o_tide_netcdf.add_metadata(args.metadata)


def _creates_variable(
    create_function: Callable,
    values: np.ndarray | None,
    optional: bool = False,
):
    # Creates an empty variable
    if values is not None or not optional:
        create_function(values)
