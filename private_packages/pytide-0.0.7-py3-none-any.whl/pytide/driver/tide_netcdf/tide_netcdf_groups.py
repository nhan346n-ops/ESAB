"""
Class NOT generated from model"""

from datetime import datetime, timezone
from enum import Enum

import netCDF4 as nc
import numpy as np

# pylint: disable=import-error
# pylint: disable=E1101
# pylint: disable=R0904
# pylint: disable=C0305
# pylint: disable=C0302

DEFAULT_COMPRESSION_LIB = "zlib"
DEFAULT_COMPRESSION_LEVEL = 4

# Global attributes
TIDE_TYPE = "tide_type"  # PREDICTED, MEASURED, UNKNOWN
TIDE_SOURCE = "tide_source"  # TIDE_GAUGE, GNSS, MODEL, UNKNOWN
VERTICAL_REFERENCE = "vertical_reference"  # ZH, MSL, LAT, WGS84
SURGE_CORRECTED = "surge_corrected"  # TRUE, FALSE

VERTICAL_DATUM = "vertical_datum"  # BathyElli v2.0 ZH/ell, BathyElli v1.0 ZH/ell, LAT_MSL_World_model_2003_2020, WGS84
PREDICTION_MODEL = "prediction_model"  # SHOM (file.har), FES2014 vX.Y, FES2022 vX.Y
REFERENCE_HEIGHT_ABOVE_ELLIPSOID = "reference_height_above_ellipsoid"

TIDE_GAUGE_LATITUDE = "tide_gauge_latitude"
TIDE_GAUGE_LONGITUDE = "tide_gauge_longitude"
TIDE_GAUGE_NAME = "tide_gauge_name"
TIDE_GAUGE_ID = "tide_gauge_id"  # SHOM identifier

COMMENT = "comment"


class VerticalReference(str, Enum):
    ZH = "ZH"  # Zero Hydrographique
    MSL = "MSL"  # Mean Sea Level
    LAT = "LAT"  # Lowest Astronomical Tide
    WGS84 = "WGS84"  # World Geodetic System 1984


class RootGrp:
    @staticmethod
    def get_group_path():
        return "/"

    def create_group(self, parent_group: nc.Dataset, **attributes):
        g = parent_group.createGroup(self.get_group_path())

        if "Conventions" not in attributes:
            g.Conventions = "CF-1.7, ACDD-1.3"  # A comma-separated list of the conventions followed in the file. Include the relevant CF and ACDD conventions (e.g. ”CF-1.7” and ”ACDD-1.3”).
        if "date_created" not in attributes:
            g.date_created = (
                datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
            )  # Timestamp of file creation in ISO8601:2004 extended format, including the time zone (e.g. 2017-05-06T20:21:35Z).
        if "tide_convention_authority" not in attributes:
            g.tide_convention_authority = "Ifremer"  # Name of the organization managing and distributing the file convention. Currently Ifremer.
        if "tide_convention_version" not in attributes:
            g.tide_convention_version = "1.0"  # Tide Netcdf version number in the form “major.minor”, where major and minor are non-negative integers.
        if "tide_convention_name" not in attributes:
            g.tide_convention_name = (
                "TIDE-netCDF4"  # Formal name of this convention (i.e. ”TIDE-netCDF4”).
            )

        # write attributes passed as argument
        for key, value in attributes.items():
            g.setncattr(key, value)

        return g

    # Variables names
    ###
    # crs variable definition
    CRS_VNAME = "crs"

    @staticmethod
    def CRS():
        return RootGrp.get_group_path() + "crs"

    def create_crs(self, group: nc.Dataset, missing_value=None, **attributes):
        """create variable crs"""
        v = group.createVariable(
            varname="crs",
            datatype=np.int32,
            dimensions=(),
            fill_value=missing_value,
            compression=DEFAULT_COMPRESSION_LIB,
        )
        if "grid_mapping_name" not in attributes:
            v.grid_mapping_name = "latitude_longitude"
        if "longitude_of_prime_meridian " not in attributes:
            v.longitude_of_prime_meridian = np.float32(0.0)
        if "semi_major_axis " not in attributes:
            v.semi_major_axis = np.float32(6378137)
        if "inverse_flattening" not in attributes:
            v.inverse_flattening = np.float32(298.257223563)
        if "crs_wkt" not in attributes:
            v.crs_wkt = "GEOGCS['WGS 84',DATUM['WGS_1984',SPHEROID['WGS 84',6378137,298.257223563,AUTHORITY['EPSG','7030']],AUTHORITY['EPSG','6326']],PRIMEM['Greenwich',0,AUTHORITY['EPSG','8901']],UNIT['degree',0.0174532925199433,AUTHORITY['EPSG','9122']],AUTHORITY['EPSG','4326']]"

        # write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    # End of crs variable definition
    ####

    # dimensions names declaration
    TIME_DIM_NAME = "time"

    def create_dimension(self, group: nc.Dataset, values: dict):
        """Pass as argument an array of dimension to be created and their values (use None for unlimited dimension)"""
        for dimension_name in values.keys():
            group.createDimension(dimension_name, values[dimension_name])

    # Coordinate Variables names
    ###
    # time variable definition
    TIME_VNAME = "time"

    @staticmethod
    def TIME():
        return RootGrp.get_group_path() + "time"

    def create_time(self, group: nc.Dataset, missing_value=None, **attributes):
        """create variable time"""
        v = group.createVariable(
            varname="time",
            datatype=np.uint64,
            dimensions=("time"),
            fill_value=missing_value,
            compression=DEFAULT_COMPRESSION_LIB,
        )
        if "axis" not in attributes:
            v.axis = "T"
        if "calendar" not in attributes:
            v.calendar = "gregorian"
        if "long_name" not in attributes:
            v.long_name = "Time-stamp of each ping"
        if "standard_name" not in attributes:
            v.standard_name = "time"
        if "units" not in attributes:
            v.units = "nanoseconds since 1970-01-01 00:00:00Z"

        # write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    # End of time variable definition
    ####

    ###
    # latitude variable definition
    LATITUDE_VNAME = "latitude"

    @staticmethod
    def LATITUDE():
        return RootGrp.get_group_path() + "latitude"

    def create_latitude(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable latitude"""
        v = group.createVariable(
            varname="latitude",
            datatype=np.float64,
            dimensions=("time"),
            fill_value=missing_value,
            compression=DEFAULT_COMPRESSION_LIB,
        )
        if "valid_range" not in attributes:
            v.valid_range = [-90.0, 90.0]
        if "standard_name" not in attributes:
            v.standard_name = "latitude"
        if "units" not in attributes:
            v.units = "degrees_north"
        if "long_name" not in attributes:
            v.long_name = "latitude"
        if "coordinates" not in attributes:
            v.coordinates = "time latitude longitude"
        if "sdn_parameter_urn" not in attributes:
            v.sdn_parameter_urn = "SDN:P01::ALATZZ01"
        if "sdn_parameter_uri" not in attributes:
            v.sdn_parameter_uri = (
                "https://vocab.nerc.ac.uk/collection/P01/current/ALATZZ01/"
            )
        if "sdn_parameter_name" not in attributes:
            v.sdn_parameter_name = "Latitude north"
        if "sdn_uom_urn" not in attributes:
            v.sdn_uom_urn = "SDN:P06::DEGN"
        if "sdn_uom_name" not in attributes:
            v.sdn_uom_name = "Degrees north"
        if "sdn_uom_uri" not in attributes:
            v.sdn_uom_uri = "https://vocab.nerc.ac.uk/collection/P06/current/DEGN/"

        # write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    # End of latitude variable definition
    ####

    ###
    # longitude variable definition
    LONGITUDE_VNAME = "longitude"

    @staticmethod
    def LONGITUDE():
        return RootGrp.get_group_path() + "longitude"

    def create_longitude(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable longitude"""
        v = group.createVariable(
            varname="longitude",
            datatype=np.float64,
            dimensions=("time"),
            fill_value=missing_value,
            compression=DEFAULT_COMPRESSION_LIB,
        )
        if "valid_range" not in attributes:
            v.valid_range = [-180.0, 180.0]
        if "standard_name" not in attributes:
            v.standard_name = "longitude"
        if "units" not in attributes:
            v.units = "degrees_east"
        if "long_name" not in attributes:
            v.long_name = "longitude"
        if "sdn_parameter_urn" not in attributes:
            v.sdn_parameter_urn = "SDN:P01::ALONZZ01"
        if "sdn_parameter_uri" not in attributes:
            v.sdn_parameter_uri = (
                "https://vocab.nerc.ac.uk/collection/P01/current/ALONZZ01/"
            )
        if "sdn_parameter_name" not in attributes:
            v.sdn_parameter_name = "Longitude east"
        if "sdn_uom_urn" not in attributes:
            v.sdn_uom_urn = "SDN:P06::DEGE"
        if "sdn_uom_name" not in attributes:
            v.sdn_uom_name = "Degrees east"
        if "sdn_uom_uri" not in attributes:
            v.sdn_uom_uri = ""

        # write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    # End of longitude variable definition
    ####

    ###
    # height_above_reference_ellipsoid variable definition
    TIDE_VNAME = "tide"

    @staticmethod
    def TIDE():
        return RootGrp.get_group_path() + "tide"

    def create_tide(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable tide"""
        v = group.createVariable(
            varname="tide",
            datatype=np.float32,
            dimensions=("time"),
            fill_value=missing_value,
            compression=DEFAULT_COMPRESSION_LIB,
        )
        if "standard_name" not in attributes:
            v.standard_name = "tide"
        if "units" not in attributes:
            v.units = "m"
        if "long_name" not in attributes:
            v.long_name = "Tide sea elevation above a reference surface (positive up)"
        if "coordinates" not in attributes:
            v.coordinates = "time latitude longitude"
        if "sdn_uom_urn" not in attributes:
            v.sdn_uom_urn = "SDN:P06::ULAA"
        if "sdn_uom_name" not in attributes:
            v.sdn_uom_name = "Metres"
        if "sdn_uom_uri" not in attributes:
            v.sdn_uom_uri = "https://vocab.nerc.ac.uk/collection/P06/current/ULAA/"

        # write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    # End of tide variable definition
    ####
