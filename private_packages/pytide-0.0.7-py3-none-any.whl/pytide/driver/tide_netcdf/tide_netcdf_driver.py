#! /usr/bin/env python3
# coding: utf-8

from contextlib import contextmanager
from os import PathLike
from typing import Callable, Generator

import netCDF4 as nc
import numpy as np
import xarray as xa
from numpy.typing import ArrayLike

import pytide.driver.tide_netcdf.tide_netcdf_groups as tide_g
from pytide.driver.abstract_tide_driver import AbstractTideDriver

# pylint: disable=unsupported-binary-operation,too-many-public-methods,unsupported-membership-test


class TideNetcdfDriver(AbstractTideDriver):
    def __init__(self, file_path: PathLike | str):
        self.file_path = file_path
        self._dataset: nc.Dataset | None = None

    def open(self, mode: str = "r") -> nc.Dataset:
        return self.nc_open(mode=mode)

    def nc_open(self, mode: str = "r", **attributes) -> nc.Dataset:
        """
        Open the file and return the resulting Dataset
        """
        self._dataset = nc.Dataset(self.file_path, mode, format="NETCDF4")
        if mode in ["w", "x"]:
            root_g = tide_g.RootGrp()
            root_g.create_group(self._dataset, **attributes)

        return self._dataset

    def get_file_path(self) -> PathLike | str | None:
        return self.file_path

    def close(self):
        """
        Close the file
        """
        if self._dataset is not None:
            self._dataset.close()
            self._dataset = None

    def create_time_var(self, times: ArrayLike, **attributes) -> nc.Variable:
        """
        Add and fill the time variable
        """
        root_g = tide_g.RootGrp()
        return self._create_one_var(
            create_method=root_g.create_time, values=times, **attributes
        )

    def create_latitude_var(self, latitudes: ArrayLike, **attributes) -> nc.Variable:
        """
        Add and fill the latitude variable
        """
        root_g = tide_g.RootGrp()
        return self._create_one_var(
            create_method=root_g.create_latitude, values=latitudes, **attributes
        )

    def create_longitude_var(self, longitudes: ArrayLike, **attributes) -> nc.Variable:
        """
        Add and fill the longitude variable
        """
        root_g = tide_g.RootGrp()
        return self._create_one_var(
            create_method=root_g.create_longitude, values=longitudes, **attributes
        )

    def create_tide_var(self, tides: ArrayLike, **attributes) -> nc.Variable:
        """
        Add and fill the tide variable
        """
        root_g = tide_g.RootGrp()
        return self._create_one_var(
            create_method=root_g.create_tide,
            values=tides,
            **attributes,
        )

    def add_metadata(self, metadata: dict[str, str]) -> None:
        """
        Add global attributes to the Tide file
        """
        for key, value in metadata.items():
            self._dataset.setncattr(key, value)

    def get_metadata(self) -> dict[str, str]:
        """
        Returns Tide file metadata
        """
        metadata = {}
        for key in self._dataset.ncattrs():
            metadata[key] = self._dataset.getncattr(key)
        return metadata

    def get_data(self, variable: str) -> np.ndarray:
        """
        Returns data of the specified variable (from navigation group).
        """
        return self._dataset.variables[variable][:]

    def get_times(self) -> np.ndarray:
        return self.get_data(tide_g.RootGrp.TIME_VNAME)

    def get_latitudes(self) -> np.ndarray:
        return self.get_data(tide_g.RootGrp.LATITUDE_VNAME)

    def get_longitudes(self) -> np.ndarray:
        return self.get_data(tide_g.RootGrp.LONGITUDE_VNAME)

    def get_tides(self) -> np.ndarray:
        return self.get_data(tide_g.RootGrp.TIDE_VNAME)

    def _create_one_var(
        self, create_method: Callable, values: ArrayLike | None, **attributes
    ) -> nc.Variable:
        """
        Add and fill the variable
        """
        # Creates dimension
        root_g = tide_g.RootGrp()
        if tide_g.RootGrp.TIME_DIM_NAME not in self._dataset.dimensions:
            root_g.create_dimension(
                group=self._dataset,
                values={tide_g.RootGrp.TIME_DIM_NAME: len(values)},
            )

        # Creates variables
        result = create_method(group=self._dataset, **attributes)
        if values is not None:
            result[:] = values

        return result

    def _has_one_var(self, var_name: str) -> bool:
        """
        Return true if file contains the specified variable
        """
        try:
            return var_name in self._dataset[tide_g.RootGrp.get_group_path()].variables
        except IndexError:
            return False


@contextmanager
def nc_open(
    file_path: PathLike | str, mode: str = "r"
) -> Generator[TideNetcdfDriver, None, None]:
    """
    Define a With Statement Context Managers for a TideNetcdfDriver
    Allow opening a TideNetcdfDriver in a With Statement
    """
    driver = TideNetcdfDriver(file_path)
    driver.nc_open(mode)
    try:
        yield driver
    finally:
        driver.close()


@contextmanager
def xarray_open(file_path: PathLike | str) -> Generator[xa.Dataset, None, None]:
    """
    Open the Tide file with XArray lib.
    Time coordinate is in a DataArray of numpy.datetime64
    """
    result = None
    try:
        result = xa.open_dataset(file_path, group=tide_g.RootGrp.get_group_path())
        yield result
    finally:
        if result is not None:
            result.close()
