from contextlib import contextmanager
from os import PathLike
from typing import Generator

import numpy as np
import pandas as pd

from pytide.driver.abstract_tide_driver import AbstractTideDriver

DATE = "date"
TIDE = "tide_value"


class TtbDriver(AbstractTideDriver):

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.dataframe = None

    def open(self, mode: str = "r"):
        """
        Open the file and return the resulting Dataset
        """
        self.dataframe = pd.read_csv(
            self.file_path,
            delimiter="\t",
            names=[DATE, TIDE],
            dtype={TIDE: float},
        )

        return self.dataframe

    def close(self):
        self.dataframe = None

    def get_file_path(self) -> PathLike | str | None:
        return self.file_path

    def get_times(self) -> np.ndarray:
        correction_dates = pd.to_datetime(
            self.dataframe[DATE], format="%d/%m/%Y %H:%M:%S.%f", utc=True
        )
        correction_dates = correction_dates.to_numpy(dtype=np.uint64)
        return correction_dates

    def get_tides(self) -> np.ndarray:
        return self.dataframe[TIDE].to_numpy()

    def get_latitudes(self) -> np.ndarray | None:
        return None

    def get_longitudes(self) -> np.ndarray | None:
        return None


@contextmanager
def open_ttb(file_path: str, mode: str = "r") -> Generator[TtbDriver, None, None]:
    """
    Context manager that opens a TtbDriver for use in a with statement.
    """
    driver = TtbDriver(file_path=file_path)
    driver.open(mode)
    try:
        yield driver
    finally:
        driver.close()
