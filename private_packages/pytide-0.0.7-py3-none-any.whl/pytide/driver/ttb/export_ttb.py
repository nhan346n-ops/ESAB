#! /usr/bin/env python3
# coding: utf-8

import logging
import os

import pandas as pd

from pytide.driver.export_tide_args import ExportTideArgs

__logger = logging.getLogger("Export CSV TTB")

# pylint: disable=unsupported-binary-operation


def exports(**kwargs) -> None:
    """
    Function accepting all arguments of the process as a dict. Possible arguments are listed in "ExportTtbArgs" class
    """
    exports_with_ExportTideArgs(ExportTideArgs(**kwargs))


def exports_with_ExportTideArgs(args: ExportTideArgs) -> None:
    """
    Main function
    Use arguments to create a TTB file
    """
    if not os.path.exists(args.o_path) or args.overwrite:
        _process_export(args)
    else:
        __logger.warning(f"{args.o_path} exists and cannot be overwritten")


def _process_export(args: ExportTideArgs) -> None:
    __logger.info(f"Exporting {args.o_path} ")
    # create a pandas dataframe from args ndarray
    df = pd.DataFrame(
        data={"time": args.time.astype("datetime64[ns]"), "tide": args.tide}
    )
    df.to_csv(
        args.o_path,
        sep="\t",
        index=False,
        columns=["time", "tide"],
        date_format="%d/%m/%Y %H:%M:%S.000",
        header=False,
        float_format="%.2f",
    )
