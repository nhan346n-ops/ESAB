import os.path
from abc import abstractmethod
from os import PathLike
from typing import runtime_checkable, Protocol, Optional

import numpy as np


@runtime_checkable
class AbstractTideDriver(Protocol):
    """
    API description of Tide driver.
    """

    @abstractmethod
    def open(self, mode: str = "r"): ...

    @abstractmethod
    def close(self): ...

    def get_name(self) -> str:
        return os.path.basename(self.get_file_path())

    @abstractmethod
    def get_file_path(self) -> PathLike | str | None: ...

    @abstractmethod
    def get_times(self) -> np.ndarray: ...

    @abstractmethod
    def get_tides(self) -> np.ndarray: ...

    @abstractmethod
    def get_latitudes(self) -> Optional[np.ndarray]: ...

    @abstractmethod
    def get_longitudes(self) -> Optional[np.ndarray]: ...

    def get_metadata(self) -> dict[str, str]:
        return {}
