from contextlib import contextmanager
from typing import Generator

from pytide.driver.abstract_tide_driver import AbstractTideDriver
from pytide.driver.export_tide_args import ExportTideArgs
from pytide.driver.ttb.export_ttb import exports_with_ExportTideArgs as ttb_exports
from pytide.driver.tide_netcdf.export_tide import (
    exports_with_ExportTideArgs as tide_netcdf_exports,
)
from pytide.driver.ttb.ttb_driver import TtbDriver
from pytide.driver.tide_netcdf.tide_netcdf_driver import TideNetcdfDriver

TTB_EXTENSION = ".ttb"
TIDE_NETCDF_EXTENSION = ".tide.nc"


@contextmanager
def open_tide(
    file_path: str, mode: str = "r"
) -> Generator[AbstractTideDriver, None, None]:
    """
    Define a "With" Statement Context Managers for a TideDriver.
    (@contextmanager to allow opening a TideDriver in a "with... as..." Statement.)

    @param mode: access mode (see NetCDF documentation for details).
    @param file_path: path of the TTB file (.ttb or .ttb.nc).
    """
    driver = get_tide_driver(file_path)
    driver.open(mode)
    try:
        yield driver
    finally:
        driver.close()


def get_tide_driver(file_path: str) -> AbstractTideDriver:
    """
    Instantiates the suitable Tide driver for the specified file.

    @param file_path: path of the Tide file (.ttb or .tide.nc).
    @return: Tide driver.
    """
    if file_path.endswith(TTB_EXTENSION):
        return TtbDriver(file_path)
    elif file_path.endswith(TIDE_NETCDF_EXTENSION):
        return TideNetcdfDriver(file_path)

    raise ValueError(f"Unsupported Tide file : {file_path}.")


def exports(**kwargs) -> None:
    """
    Function accepting all arguments of the process as a dict. Possible arguments are listed in "ExportTideArgs" class
    """
    export_args = ExportTideArgs(**kwargs)
    if export_args.o_path.endswith(TTB_EXTENSION):
        ttb_exports(export_args)
    elif export_args.o_path.endswith(TIDE_NETCDF_EXTENSION):
        tide_netcdf_exports(export_args)


def exports_with_ExportTideArgs(args: ExportTideArgs) -> None:
    """
    Function accepting all arguments of the process as a dict. Possible arguments are listed in "ExportTideArgs" class
    """
    if args.o_path.endswith(TTB_EXTENSION):
        ttb_exports(args)
    elif args.o_path.endswith(TIDE_NETCDF_EXTENSION):
        tide_netcdf_exports(args)
