from pathlib import Path
from typing import Tuple

import numpy as np

from pytide.core.fes2014.fes_tide_predict import FESTideComputer
from pytide.core.shom_harmonic.shom_harmonic_tide_predict import ShomTidePredictor
from pytide.core.surface_reference.sea_surface import SeaSurfaceProjector


def _update_surface_reference(
    model_dir: Path, latitudes: np.ndarray, longitudes: np.ndarray, tides: np.ndarray
) -> np.ndarray:
    """
    Apply offset to switch from MSL to LAT reference
    :param model_dir: path to the surface_reference model directory
    """
    proj = SeaSurfaceProjector(model_dir=model_dir)
    return proj.project_msl_to_lat(
        longitudes=longitudes, latitudes=latitudes, values=tides
    )


def compute_tides_with_fes_model(
    fes_model_dir: Path,
    surface_reference_parent_dir: Path,
    latitudes: np.ndarray,
    longitudes: np.ndarray,
    dates: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Compute tide for latitudes, longitudes and dates with FES2014 model
    :param model_dir: path to FES model directory
    :param surface_reference_parent_dir: path to folder containing surface_reference model
    :param longitudes: array of longitudes
    :param latitudes: array of latitudes
    :param dates: array of dates. Type is a 64-bit datetime, with the precision set to seconds (ie datetime64[s])
    """
    predictor = FESTideComputer(model_dir=fes_model_dir)
    _lats, _lons, _dates, _computed_tides, *_ = predictor.compute_tides(
        latitudes=latitudes, longitudes=longitudes, dates=dates
    )

    _tides = _update_surface_reference(
        model_dir=surface_reference_parent_dir,
        latitudes=_lats,
        longitudes=_lons,
        tides=_computed_tides,
    )
    return _dates, _lats, _lons, _tides


def compute_tides_with_shom_model(
    model_dir: Path, latitudes: np.ndarray, longitudes: np.ndarray, dates: np.ndarray
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Compute tide for latitudes, longitudes and dates with SHOM model
    :param model_dir: path to the SHOM model directory
    :param latitudes: array of latitudes
    :param longitudes: array of longitudes
    :param dates: array of dates. Type is a 64-bit datetime, with the precision set to seconds (ie datetime64[s])
    """
    predictor = ShomTidePredictor(harmonic_file=str(model_dir))
    _lats, _lons, _dates, _tides, *_ = predictor.compute_tides(
        latitudes, longitudes, dates
    )

    return _dates, _lats, _lons, _tides
