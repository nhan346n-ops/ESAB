import numpy as np
from osgeo import gdal


def netcdf_to_gdal(value: np.ndarray):
    """Convert a netcdf dataset array with origin left bottom to a gdal dataset array with upper left origin convention"""
    return value[::-1, :]


def gdal_to_netcdf(gdal_dataset: gdal.Dataset):
    """Convert a gdal dataset array with upper left origin convention to a netcdf array convention with origin left bottom"""
    return gdal_dataset.ReadAsArray()[::-1, :]


def get_x_y_coordinates(gdal_dataset: gdal.Dataset):
    """
    Compute and return two X (longitude) and Y (latitude) coordinates vector from a gdal dataset
    The coordinates computed refers to the coordinates at the center of the cells
    Args:
        gdal_dataset:

    Returns:
        (x,y) the coordinates vector
    """
    (GT_0, GT_1, GT_2, GT_3, GT_4, GT_5) = gdal_dataset.GetGeoTransform()
    Xvalues = np.arange(0, gdal_dataset.RasterXSize)
    Yvalues = np.arange(0, gdal_dataset.RasterYSize)

    Xgeo = GT_0 + (Xvalues + 0.5) * GT_1 + 0 * GT_2
    Ygeo = GT_3 + 0 * GT_4 + (Yvalues + 0.5) * GT_5
    return Xgeo, Ygeo
