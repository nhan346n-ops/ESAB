import locale
import logging
import os
import tempfile
from pathlib import Path
from shutil import rmtree

import numpy as np
import pyfes

from pytide.core.common import array_commons as util

# pylint: disable=W0621
# from pyat.core.utils.monitor import ProgressMonitor


class FESTideComputer:
    def __copy_and_replace_pattern(
        self, input_path: str, output_path: str, input_pattern: str, output_pattern: str
    ) -> str:
        """
        Copy input file and replace string occurences
        Args:
            input_path : input file path
            output_path : output file path
            input_pattern : source pattern to be replaced
            output_pattern : destination pattern

        Returns:
            the output file name
        """
        with (
            open(input_path, "r", encoding=locale.getpreferredencoding()) as file_in,
            open(output_path, "w", encoding=locale.getpreferredencoding()) as file_out,
        ):
            lines = file_in.readlines()
            file_out.writelines(
                [x.replace(input_pattern, output_pattern) for x in lines]
            )
        return output_path

    def __init__(self, model_dir: Path):
        """Initialize parameters for FES Model"""
        module_dir = os.path.realpath(os.path.dirname(__file__))
        self.model_dir = model_dir

        # I do not know why but relative paths in .ini file fails on windows.
        # Copy .ini files in a temp directory replace relative path with static path where datamodel is deployed

        self.tmpdir = tempfile.mkdtemp(suffix="_tide_model")
        # Not used. Comment to allow the deletion of ocean_tide directory from datasets
        # self.ocean_tide_parameters = self.__copy_and_replace_pattern(
        #     input_path=os.path.join(module_dir, "file_pattern", "ocean_tide.yaml"),
        #     output_path=os.path.join(self.tmpdir, "ocean_tide.yaml"),
        #     input_pattern="./ocean_tide",
        #     output_pattern=os.path.join(self.model_dir, "ocean_tide"),
        # )

        self.load_tide_parameters = self.__copy_and_replace_pattern(
            input_path=os.path.join(module_dir, "file_pattern", "load_tide.yaml"),
            output_path=os.path.join(self.tmpdir, "load_tide.yaml"),
            input_pattern="./load_tide",
            output_pattern=os.path.join(self.model_dir, "load_tide"),
        )

        self.ocean_tide_extrapolated_parameters = self.__copy_and_replace_pattern(
            input_path=os.path.join(
                module_dir, "file_pattern", "ocean_tide_extrapolated.yaml"
            ),
            output_path=os.path.join(self.tmpdir, "ocean_tide_extrapolated.yaml"),
            input_pattern="./ocean_tide_extrapolated",
            output_pattern=os.path.join(self.model_dir, "ocean_tide_extrapolated"),
        )

    def __del__(self):
        rmtree(self.tmpdir)

    def compute_tides(
        self,
        latitudes: np.ndarray,
        longitudes: np.ndarray,
        dates: np.ndarray,
        # monitor: ProgressMonitor,
    ):
        """
        Compute tide for latitudes, longitudes and dates with FES2014 model,


        FES2014 was produced by NOVELTIS, LEGOS, CLS Space Oceanography Division and CNES. It is distributed by AVISO, with support from CNES (http://www.aviso.altimetry.fr/)


        Bibliography

        Lyard F., L. Carrere, M. Cancet, A. Guillot, N. Picot: FES2014, a new finite elements tidal model for global ocean, in preparation, to be submitted to Ocean Dynamics in 2016.

        Carrere L., F. Lyard, M. Cancet, A. Guillot, N. Picot: FES 2014, a new tidal model - Validation results and perspectives for improvements, presentation to ESA Living Planet Conference, Prague 2016.

        Args:
            longitudes: the longitudes array, shape of latitudes and longitudes must always be equals
            latitudes: the latitudes array, shape of latitudes and longitudes must always be equals
            dates: the date of interest array either datetime object or 'datetime64[us]' numpy array. Lenght of dates or (latitude or longitude) must be equals or of size 1


        Returns:
            (lats,lons,dates,tide_msl,tide_base,lp,load,load_lp) tuple containing
            lats: A latitude vector array
            longs: A longitude vector array
            dates: A date vector array, either datetime object or datetime64[us] depending of input parameter tide
            tide_msl : Tide relative to MSL, tide_msl = tide_base + lp + load + load_lp
            tide_base : Computed height of the diurnal and semi-diurnal constituents of the tidal spectrum
            lp : Computed height of the long period wave constituents of the tidal spectrum
            load : Computed height for the load components
            load_lp : Computed height of the long period wave constituents for the load components

        """

        # monitor.begin_task(name="Computing tide on FES model", n=2)
        logging.getLogger(self.__class__.__name__).info("Computing tide on FES model")
        longitudes, latitudes, dates = util.reshape_args(
            lats=latitudes, lons=longitudes, dates=dates
        )
        bbox = (
            np.floor(np.nanmin(longitudes) - 1.0),
            np.floor(np.nanmin(latitudes) - 1.0),
            np.ceil(np.nanmax(longitudes) + 1.0),
            np.ceil(np.nanmax(latitudes) + 1.0),
        )

        # we need to use datetime64 type, fes model seems to interpret python datetime objects as local time instead of UTC
        dates = dates.astype("datetime64[us]")
        # Create handler
        short_tide = pyfes.config.load(
            self.ocean_tide_extrapolated_parameters, bbox=bbox
        )
        radial_tide = pyfes.config.load(self.load_tide_parameters, bbox=bbox)

        # disable pylint warning for unpacking non sequence
        # pylint: disable=W0633
        tide, lp, _ = pyfes.evaluate_tide(
            tidal_model=short_tide.models["tide"],
            date=dates,
            longitude=longitudes,
            latitude=latitudes,
        )
        # monitor.worked(1)
        # set units to meter
        tide *= 0.01
        lp *= 0.01
        load, load_lp, _ = pyfes.evaluate_tide(
            tidal_model=radial_tide.models["radial"],
            date=dates,
            longitude=longitudes,
            latitude=latitudes,
        )
        load *= 0.01
        load_lp *= 0.01
        # monitor.worked(1)
        return (
            latitudes,
            longitudes,
            dates,
            tide + lp + load + load_lp,
            tide,
            lp,
            load,
            load_lp,
        )

    def get_prediction_model(self) -> str:
        """Return the model version used"""
        return "FES 2014 v1.2"
