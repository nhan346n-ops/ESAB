import pathlib

import netCDF4 as nc


class ConstantGenerator:
    def __init__(self):
        self.input_files_dir = None
        self.output_dir = None

    def generate_from_dir(self, techsas_dir: str, output_dir: str):
        self.input_files_dir = techsas_dir
        self.output_dir = output_dir
        extensions_set = set()
        variables_dict = set()

        # find and read techsas files
        if self.input_files_dir:
            # parse input files directory
            input_files_path = pathlib.Path(self.input_files_dir)
            for infile in input_files_path.rglob("*"):
                if infile.is_file():
                    # get last element of filename
                    extension = infile.name.split(".")[-1]
                    extensions_set.add(extension)
                    # parse dimensions
                    try:
                        with nc.Dataset(infile) as dataset:
                            for v_key in dataset.variables.keys():
                                data = dataset.variables[v_key]
                                v_unit = data.units
                                variables_dict.add((extension, v_key, v_unit))
                    except OSError as err:
                        print("OS error: {0}".format(err))

            # process keys
            # pylint:disable = consider-using-dict-items
            output_files_path = pathlib.Path(self.input_files_dir)
            for extensions_key in extensions_set:
                entries = [(key, unit) for (ext, key, unit) in variables_dict if ext == extensions_key]
                file = open(file=output_files_path.joinpath(f"{extensions_key}.py"), mode='w')
                file.write(f"#file generated ")

                for (key, unit) in entries:
                    file.write(f"{extensions_key.upper()}_{str(key).upper()}_DIM_NAME = \"{str(key)}\"\n")
                    file.write(f"{extensions_key.upper()}_{str(key).upper()}_DIM_UNIT = \"{str(unit)}\"\n")
                file.close()


if __name__ == "__main__":
    ConstantGenerator().generate_from_dir("C:/Users/asaunier/Documents/Data/PEACETIME", "C:/Users/asaunier/Documents/Data/PEACETIME")
