#! /usr/bin/env python3
# coding: utf-8

import logging
from typing import List

import xarray as xr

import pytechsas.sensor.constant_mapping as cm
import pytechsas.sensor.netcdf_constant as nc
from pytechsas.sensor.quality_flag import VALID_QUALITY_FLAGS

logger = logging.getLogger(__name__)


def export_files(
    i_paths: List[str], o_path: str, layers: List[str] | None = None, separator: str = ";", valid_data_only=True
):
    """
    Export NetCDF files to a CSV file.

    Args:
        i_paths: List of paths to input NetCDF files.
        o_path: Path to output CSV file.
        layers: List of variable names to export. If None, exports all data variables.
        separator: CSV column separator character.
        valid_data_only: If True, filters out invalid data based on quality_frag variable.
    """
    with xr.open_mfdataset(paths=i_paths) as ds:
        # Get variable names from file
        var_names = cm.guess_var_names(ds)

        # Filter out invalid data if requested
        if valid_data_only and var_names.VAR_QUALITY_FLAG in ds:
            logger.info("Removing invalid data based on quality_frag variable")
            mask = ds[var_names.VAR_QUALITY_FLAG].isin(list(VALID_QUALITY_FLAGS)).compute()
            ds = ds.where(mask, drop=True)

        # Default to all data variables if no layers specified
        if not layers:
            layers = list(ds.data_vars.keys())

        # Exclude quality_frag and CRS variables from export
        for excluded_var in [var_names.VAR_QUALITY_FLAG, nc.VAR_CRS]:
            if excluded_var in layers:
                layers.remove(excluded_var)

        # Filter dataset to selected layers
        logger.info("Exporting layers: %s", layers)
        ds = ds[layers]

        # Convert to pandas DataFrame and export to CSV
        df = ds.to_dataframe().reset_index()
        df.to_csv(o_path, sep=separator, header=True, index=False, date_format="%Y-%m-%dT%H:%M:%S.%f")
