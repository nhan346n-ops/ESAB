#! /usr/bin/env python3
# coding: utf-8

import logging
import os
import uuid
from pathlib import Path

import xarray as xr

import pytechsas.sensor.sensor_constant as sc

logger = logging.getLogger(__name__)


def write_dataset_to_netcdf(ds: xr.Dataset, netcdf_path: str):
    """Write Dataset to NetCDF4 file with custom time encoding."""

    logger.info(f"Writing netCDF file {netcdf_path}")

    if sc.SENSOR_VAR_TIME in ds and ds[sc.SENSOR_VAR_TIME].dtype != "int64":
        ds = ds.copy(deep=True)
        ds[sc.SENSOR_VAR_TIME] = ds[sc.SENSOR_VAR_TIME].astype("int64")
        ds[sc.SENSOR_VAR_TIME].attrs = {"units": "nanoseconds since 1970-01-01 00:00:00Z", "calendar": "gregorian"}

    # Create a temporary file in the same directory as the final file
    # This workaround is needed because netCDF4 library doesn't handle Unicode characters
    # (accented characters) correctly in filenames on Windows
    final_path = Path(netcdf_path)
    temp_name = f"temp_{uuid.uuid4().hex}.nc"
    temp_path = final_path.parent / temp_name

    # Write to temporary file (ASCII-safe name)
    ds.to_netcdf(temp_path, engine="netcdf4", format="NETCDF4")

    # Rename to final path (may contain accented characters)
    if os.path.exists(final_path):
        os.unlink(final_path)
    os.rename(temp_path, final_path)
    logger.info(f"NetCDF file written successfully: {final_path}")
