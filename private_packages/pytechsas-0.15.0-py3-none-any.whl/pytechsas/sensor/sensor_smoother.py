#! /usr/bin/env python3
# coding: utf-8

"""
Sensor data smoothing module for NetCDF files.

This module provides functionality to apply various smoothing algorithms
to sensor data stored in NetCDF format, such as turbidity and salinity measurements.
"""

import logging
import os
import shutil
from typing import List

import xarray as xr

from pytechsas.sensor.techsas_file import add_history
from pytechsas.utils.smooth import smooth_array

logger = logging.getLogger(__name__)


def apply_smoothing(
    i_path: str,
    o_path: str,
    layers: List[str],
    algorithm: str = "savgol",  #  savgol, butter, bessel, bessel_q, medfilt
    order=2,
    window_size=10,
    critical_freq=0.2,
    sampling_freq=1.0,
):
    """
    Apply smoothing filter to specified layers in a NetCDF dataset.

    Args:
        i_path: Path to input NetCDF file
        o_path: Path to output NetCDF file
        layers: List of variable names to smooth
        algorithm: Smoothing algorithm to use (savgol, butter, bessel, bessel_q, medfilt)
        order: Filter order (for savgol: polynomial order, for others: filter order)
        window_size: Window size for Savitzky-Golay and median filters
        critical_freq: Critical frequency for frequency-based filters
        sampling_freq: Sampling frequency of the data
    """
    if not os.path.exists(i_path):
        logger.error(f"Input file {i_path} does not exist. Nothing to do.")
        return

    # Copy input to output first to preserve all original data
    if not os.path.exists(o_path) or not os.path.samefile(i_path, o_path):
        logger.info(f"Copying {i_path} to {o_path}")
        shutil.copy2(i_path, o_path)

    logger.info(f"Opening dataset: {i_path}")
    with xr.open_dataset(i_path) as in_ds:
        # Apply smoothing on specified layers
        out_ds = apply_smoothing_on_ds(in_ds, layers, algorithm, window_size, order, critical_freq, sampling_freq)

        if len(out_ds.data_vars) > 0:
            # Save smoothed layers and update history
            _add_history(in_ds, out_ds, algorithm)
            out_ds.to_netcdf(o_path, mode="a", engine="netcdf4", format="NETCDF4")
            logger.info(f"Smoothed dataset saved to: {o_path}")
        else:
            logger.warning("No valid layers found to smooth.")


def apply_smoothing_on_ds(
    ds: xr.Dataset,
    layers: List[str],
    algorithm: str,
    window_size: int,
    order: int,
    critical_freq: float,
    sampling_freq: float,
) -> xr.Dataset:
    """
    Apply smoothing filter to specified variables in the dataset.

    Args:
        ds: Input xarray Dataset
        layers: List of variable names to smooth
        algorithm: Smoothing algorithm to use
        window_size: Window size for Savitzky-Golay filter
        order: Filter order
        critical_freq: Critical frequency for frequency-based filters
        sampling_freq: Sampling frequency of the data

    Returns:
        xarray Dataset containing only the smoothed variables
    """
    result = xr.Dataset()

    for layer in layers:
        if layer in ds.data_vars:
            logger.info(f"Smoothing layer: {layer}")
            xrLayer = ds[layer]
            # Apply smoothing algorithm and preserve layer structure
            result[layer] = xrLayer.copy(
                data=smooth_array(ds[layer].values, algorithm, window_size, order, critical_freq, sampling_freq)
            )
        else:
            logger.warning(f"Layer '{layer}' not found in dataset. Skipping.")

    return result


def _add_history(in_ds: xr.Dataset, out_ds: xr.Dataset, algorithm: str):
    """
    Add history attribute to track the smoothing operation applied.
    """
    add_history(
        origin_ds=in_ds,
        new_ds=out_ds,
        module_name=os.path.basename(__file__),
        history_info=(f"Smoothed with '{algorithm}' algorithm"),
    )
