"""
Quality Flag Management for Sensor and TECHSAS Data

Provides quality control functionality following SeaDataNet standards for sensor data
and custom status flags for TECHSAS files. Handles flag creation, merging, and filtering
of datasets based on quality criteria.

Quality flags follow SeaDataNet vocabulary L20:
https://vocab.seadatanet.org/v_bodc_vocab_v2/search.asp?lib=L20
"""

from enum import IntEnum

import numpy as np
import xarray as xr

import pytechsas.sensor.sensor_constant as sc
import pytechsas.sensor.techsas_constant as tc


class QualityFlag(IntEnum):
    """
    SeaDataNet quality flags for sensor data.

    These standardized flags indicate the quality and processing status of individual
    sensor measurements. Values 0-2, 5, and 8 are considered valid for analysis.

    Reference: https://vocab.seadatanet.org/v_bodc_vocab_v2/search.asp?lib=L20
    """

    NO_QUALITY_CONTROL = 0  # No QC performed yet
    GOOD_VALUE = 1  # Passed all QC tests
    PROBABLY_GOOD_VALUE = 2  # Passed most QC tests
    PROBABLY_BAD_VALUE = 3  # Failed some QC tests
    BAD_VALUE = 4  # Failed critical QC tests
    CHANGED_VALUE = 5  # Value modified by QC process
    VALUE_BELOW_DETECTION = 6  # Below instrument detection limit
    VALUE_IN_EXCESS = 7  # Exceeds instrument range
    INTERPOLATED_VALUE = 8  # Filled by interpolation
    MISSING_VALUE = 9  # No data available


# Quality flags considered acceptable for scientific analysis
VALID_QUALITY_FLAGS = {
    QualityFlag.NO_QUALITY_CONTROL,
    QualityFlag.GOOD_VALUE,
    QualityFlag.PROBABLY_GOOD_VALUE,
    QualityFlag.CHANGED_VALUE,
    QualityFlag.INTERPOLATED_VALUE,
}


def create_valid_quality_mask(quality_flags_var_name: str, quality_flags: np.ndarray) -> np.ndarray:
    """Create boolean mask identifying valid quality flags.

    Generates a boolean array where True indicates valid/acceptable data and False
    indicates invalid/rejected data, based on the quality flag standards for each
    file format.

    Args:
        quality_flags_var_name: Variable name determining the format (sensor or TECHSAS)
        quality_flags: Array of quality flag or status values

    Returns:
        Boolean mask array where True = valid data, False = invalid data
    """
    # Sensor-netCDF file: check if flags are in valid set
    if quality_flags_var_name == sc.SENSOR_VAR_QUALITY_FLAG:
        return np.isin(quality_flags, list(VALID_QUALITY_FLAGS))

    # TECHSAS file: valid only when status is 0
    return quality_flags == 0


def filter_dataset_by_quality(ds: xr.Dataset) -> xr.Dataset:
    """Remove invalid data points from dataset based on quality flags.

    Filters the dataset to keep only data points with valid quality indicators:
    - For sensor data: keeps only data with quality flags in VALID_QUALITY_FLAGS set
      (values 0, 1, 2, 5, 8)
    - For TECHSAS data: keeps only data where status == 0

    Args:
        ds: xarray Dataset containing quality flag or status variable

    Returns:
        Filtered dataset with invalid data points removed
    """
    # Sensor-netCDF file: filter by quality flag values
    if sc.SENSOR_VAR_QUALITY_FLAG in ds:
        mask = ds[sc.SENSOR_VAR_QUALITY_FLAG].isin(list(VALID_QUALITY_FLAGS)).compute()
        return ds.where(mask, drop=True)

    # TECHSAS file: filter by status values
    if tc.TECHSAS_STATUS in ds:
        # TECHSAS file: filter by zero status
        return ds.where(ds[tc.TECHSAS_STATUS] == 0, drop=True)

    return ds


def initialize_and_merge_quality_flags(
    ds: xr.Dataset, quality_flags_var_name: str, quality_flags_mask: np.ndarray
) -> xr.DataArray:
    """Initialize quality flags from mask and merge with existing flags if present.

    Creates a new quality flag array from a boolean mask, where True indicates valid
    data and False indicates invalid data. If the dataset already contains quality
    flags for the specified variable, the new flags are merged with the existing ones
    while preserving any previously marked bad/invalid data.

    The merging strategy ensures that once data is marked as invalid, it remains
    invalid even if subsequent quality control passes don't detect the issue.

    Args:
        ds: xarray Dataset that may contain existing quality flags
        quality_flags_var_name: Name of the quality flag variable, determines format:
            - sc.SENSOR_VAR_QUALITY_FLAG for SeaDataNet quality flags (0-9)
            - Other names for TECHSAS status flags (0=valid, non-zero=invalid)
        quality_flags_mask: Boolean array where True=valid data, False=invalid data

    Returns:
        xarray.DataArray containing the initialized (and possibly merged) quality flags
        with appropriate metadata and attributes for the file format
    """
    status_values = _initialize_quality_flags_with_mask(
        quality_flags_var_name=quality_flags_var_name, mask=quality_flags_mask
    )

    # Merge with existing variable if exists
    if quality_flags_var_name in ds:
        status_values = _merge_quality_flags_preserving_bad(
            quality_flags_var_name, ds[quality_flags_var_name].values, status_values
        )
    quality_flag_data_array = _create_quality_flag_variable(quality_flags_var_name, status_values)

    return quality_flag_data_array


def _create_sensor_quality_flag_variable(quality_flags: np.ndarray) -> xr.DataArray:
    """Create CF-compliant quality flag variable for sensor data.

    Builds a DataArray with SeaDataNet quality flags and proper CF metadata
    attributes for Sensor-netCDF files.

    Args:
        quality_flags: Array of quality flag values (0-9)

    Returns:
        xarray.DataArray with quality flag data and CF attributes
    """
    return xr.DataArray(
        quality_flags,
        dims=sc.SENSOR_VAR_TIME,
        attrs={
            "standard_name": "quality_flag",
            "long_name": "quality flag",
            "flag_values": "0b,1b,2b,3b,4b,5b,6b,7b,8b,9b",
            "flag_meanings": "no_quality_control good_value probably_good_value probably_bad_value bad_value changed_value value_below_detection value_in_excess interpolated_value missing_value",
        },
    )


def _create_techsas_status_variable(status_values: np.ndarray) -> xr.DataArray:
    """Create status flag variable for TECHSAS data files.

    Builds a DataArray with bit-masked status flags for TECHSAS NetCDF files.
    Status values use bit fields where any non-zero value indicates invalid data.

    Args:
        status_values: Array of status values (0 = valid, non-zero = invalid)

    Returns:
        xarray.DataArray with status data and metadata attributes
    """
    return xr.DataArray(
        data=status_values,
        dims=tc.TECHSAS_TIME,
        attrs={
            "long_name": "status",
            "flag_meanings": "rejected_by_user, rejected_by_turn_filter",
            "flag_mask": "1b,2b,4b,8b,16b,32b,64b",
            "comment": "status flag: if any bit field is set (value != 0) the data are considered invalid",
        },
    )


def _initialize_quality_flags_with_mask(quality_flags_var_name: str, mask: np.ndarray) -> np.ndarray:
    """Initialize quality flag array with specified mask.

    Creates a new quality flag array where values are marked as valid (GOOD_VALUE
    for sensor data, 0 for TECHSAS data) when mask value is True and values are marked as invalid
    (BAD_VALUE for sensor data, 1 for TECHSAS data) when mask value is False.

    Args:
        quality_flags_var_name: Variable name determining the format (sensor or TECHSAS)
        mask: Numpy array of bool

    Returns:
        Initialized quality flag array
    """
    # Sensor-netCDF file format: use SeaDataNet quality flags
    if quality_flags_var_name == sc.SENSOR_VAR_QUALITY_FLAG:
        quality_flags = np.full_like(mask, dtype=np.int8, fill_value=QualityFlag.BAD_VALUE.value)
        quality_flags[mask] = QualityFlag.GOOD_VALUE.value
        return quality_flags

    # TECHSAS file format: use binary status (0=valid, 1=invalid)
    status = np.zeros_like(mask, dtype=np.int8)
    status[mask] = 1
    return status


def _merge_quality_flags_preserving_bad(
    quality_flags_var_name: str, existing_flags: np.ndarray, new_flags: np.ndarray
) -> np.ndarray:
    """Merge two quality flag arrays, preserving existing bad/invalid flags.

    Combines existing and new quality flags such that:
    - For sensor data: keeps old flag if it indicates bad quality (not in VALID_QUALITY_FLAGS),
      otherwise uses new flag
    - For TECHSAS data: keeps old flag if non-zero (invalid), otherwise uses new flag

    This ensures that once data is marked as bad, it stays marked as bad even if
    subsequent QC passes don't detect the issue.

    Args:
        quality_flags_var_name: Variable name determining the format (sensor or TECHSAS)
        existing_flags: Current quality flags
        new_flags: New quality flags from recent QC check

    Returns:
        Merged quality flag array
    """
    # Sensor-netCDF file: preserve flags not in VALID_QUALITY_FLAGS set
    if quality_flags_var_name == sc.SENSOR_VAR_QUALITY_FLAG:
        return np.where(
            np.isin(existing_flags, list(VALID_QUALITY_FLAGS)),
            new_flags,  # Use new flag if old flag was valid
            existing_flags,  # Keep old flag if it was invalid
        )

    # TECHSAS file: preserve non-zero (invalid) status values
    return np.where(
        existing_flags == 0,
        new_flags,  # Use new flag if old status was 0 (valid)
        existing_flags,  # Keep old flag if status was non-zero (invalid)
    )


def _create_quality_flag_variable(quality_flags_var_name: str, quality_flags: np.ndarray) -> xr.DataArray:
    """Create appropriate quality flag DataArray based on variable name.

    Factory function that creates either a sensor quality flag variable (with
    SeaDataNet flags 0-9) or a TECHSAS status variable (with binary 0/1 values)
    depending on the specified variable name.

    Args:
        quality_flags_var_name: Variable name determining the format
        quality_flags: Array of quality flag or status values

    Returns:
        xarray.DataArray with appropriate structure and metadata
    """
    # Sensor-netCDF file format
    if quality_flags_var_name == sc.SENSOR_VAR_QUALITY_FLAG:
        return _create_sensor_quality_flag_variable(quality_flags)

    # TECHSAS file format
    return _create_techsas_status_variable(quality_flags)
