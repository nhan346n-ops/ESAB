# Specific constants for Sensor-netCDF files


# attributes
from enum import Enum
from typing import Any, Dict

import pytechsas.sensor.netcdf_constant as nc

DATE_CREATED = "date_created"
CONVENTION_AUTHORITY = "convention_authority"
CONVENTION_AUTHORITY_VALUE = "Ifremer"
CONVENTIONS = "Conventions"
CONVENTIONS_VALUE = "CF-1.7, ACDD-1.3"

CRUISE_IDENTIFIER = "cruise_identifier"
CRUISE_NAME = "cruise_name"
SENSOR_NAME = "sensor_name"


class ContentType(str, Enum):
    """Enumeration of all possible content types for CSV columns."""

    TIMESTAMP = "TIMESTAMP"
    DATETIME = "DATETIME"
    DATE = "DATE"
    TIME = "TIME"

    LATITUDE = "LATITUDE"
    LONGITUDE = "LONGITUDE"
    HEADING = "HEADING"
    SPEED = "SPEED"
    DEPTH = "DEPTH"

    TURBIDITY = "TURBIDITY"
    REDOX = "REDOX"
    SALINITY = "SALINITY"
    SOUND_VELOCITY = "SOUND_VELOCITY"
    PRESSURE = "PRESSURE"
    TEMPERATURE = "TEMPERATURE"
    CONDUCTIVITY = "CONDUCTIVITY"
    PH = "PH"

    VALUE = "VALUE"


# NetCDF Variable names
SENSOR_VAR_TIME = "time"
SENSOR_VAR_LATITUDE = "latitude"
SENSOR_VAR_LONGITUDE = "longitude"
SENSOR_VAR_HEADING = "heading"
SENSOR_VAR_GND_SPEED = "speed_over_ground"
SENSOR_VAR_GND_COURSE = "gndcourse"
SENSOR_VAR_QUALITY_FLAG = "quality_flag"

# NetCDF Variable definition (variable name, attributes) for each ContentType
# Variable names constants
SENSOR_VAR_DEPTH = "depth"
SENSOR_VAR_TURBIDITY = "turbidity"
SENSOR_VAR_REDOX = "redox"
SENSOR_VAR_SALINITY = "salinity"
SENSOR_VAR_SOUND_VELOCITY = "sound_velocity"
SENSOR_VAR_PRESSURE = "pressure"
SENSOR_VAR_TEMPERATURE = "temperature"
SENSOR_VAR_CONDUCTIVITY = "conductivity"
SENSOR_VAR_PH = "ph"

NC_VAR_ATTRIBUTES: Dict[ContentType, Any] = {
    ContentType.TIMESTAMP: {nc.LONG_NAME_ATTR: "Time-stamp", nc.STANDARD_NAME_ATTR: "time"},
    ContentType.LATITUDE: {
        nc.STANDARD_NAME_ATTR: nc.VAR_LATITUDE_STANDARD_NAME,
        nc.LONG_NAME_ATTR: nc.VAR_LATITUDE_LONG_NAME,
        nc.UNITS_ATTR: nc.VAR_LATITUDE_UNITS,
        nc.VALID_RANGE_ATTR: nc.VAR_LATITUDE_VALID_RANGE,
        "sdn_parameter_urn": "SDN:P01::ALATZZ01",
        "sdn_parameter_uri": "https://vocab.nerc.ac.uk/collection/P01/current/ALATZZ01/",
        "sdn_parameter_name": "Latitude north",
        "sdn_uom_urn": "SDN:P06::DEGN",
        "sdn_uom_name": "Degrees north",
        "sdn_uom_uri": "https://vocab.nerc.ac.uk/collection/P06/current/DEGN/",
    },
    ContentType.LONGITUDE: {
        nc.STANDARD_NAME_ATTR: nc.VAR_LONGITUDE_STANDARD_NAME,
        nc.LONG_NAME_ATTR: nc.VAR_LONGITUDE_LONG_NAME,
        nc.UNITS_ATTR: nc.VAR_LONGITUDE_UNITS,
        nc.VALID_RANGE_ATTR: nc.VAR_LONGITUDE_VALID_RANGE,
        "sdn_parameter_urn": "SDN:P01::ALONZZ01",
        "sdn_parameter_uri": "https://vocab.nerc.ac.uk/collection/P01/current/ALONZZ01/",
        "sdn_parameter_name": "Longitude east",
        "sdn_uom_urn": "SDN:P06::DEGE",
        "sdn_uom_name": "Degrees east",
        "sdn_uom_uri": "https://vocab.nerc.ac.uk/collection/P06/current/DEGE/",
    },
    ContentType.SPEED: {
        nc.STANDARD_NAME_ATTR: nc.VAR_GND_SPEED_STANDARD_NAME,
        nc.LONG_NAME_ATTR: nc.VAR_GND_SPEED_LONG_NAME,
        nc.UNITS_ATTR: nc.VAR_GND_SPEED_UNITS,
        nc.VALID_MIN: nc.VAR_GND_SPEED_VALID_MIN,
        "sdn_parameter_urn": "SDN:P01::APSAZZ01",
        "sdn_parameter_uri": "https://vocab.nerc.ac.uk/collection/P01/current/APSAZZ01/",
        "sdn_parameter_name": "Speed of measurement platform relative to ground surface {speed over ground}",
        "sdn_uom_urn": "SDN:P06::UVAA",
        "sdn_uom_name": "Metres per second",
        "sdn_uom_uri": "https://vocab.nerc.ac.uk/collection/P06/current/UVAA/",
    },
    ContentType.HEADING: {
        nc.STANDARD_NAME_ATTR: nc.VAR_HEADING_STANDARD_NAME,
        nc.LONG_NAME_ATTR: nc.VAR_HEADING_LONG_NAME,
        nc.UNITS_ATTR: nc.VAR_HEADING_UNITS,
        nc.VALID_RANGE_ATTR: nc.VAR_HEADING_VALID_RANGE,
        "sdn_parameter_urn": "SDN:P01::HEADPT01",
        "sdn_parameter_uri": "https://vocab.nerc.ac.uk/collection/P01/current/HEADPT01/",
        "sdn_parameter_name": "Orientation (horizontal) of measurement platform relative to True North {heading} in the water body by estimation using best available on-board navigation system and algorithm",
        "sdn_uom_urn": "SDN:P06::UAAA",
        "sdn_uom_name": "Degrees",
        "sdn_uom_uri": "https://vocab.nerc.ac.uk/collection/P06/current/UAAA/",
    },
    ContentType.DEPTH: {
        nc.STANDARD_NAME_ATTR: "depth",
        nc.COMMENT_ATTR: "The distance of a sensor or sampling point below the sea surface",
        nc.UNITS_ATTR: "m",
        "positive": "down",
        "sdn_parameter_urn": "SDN:P09::DEPH",
        "sdn_parameter_uri": "https://vocab.nerc.ac.uk/collection/P09/current/DEPH/",
    },
    ContentType.SALINITY: {
        nc.STANDARD_NAME_ATTR: "salinity",
        nc.UNITS_ATTR: "PSU",
    },
    ContentType.SOUND_VELOCITY: {
        nc.STANDARD_NAME_ATTR: "sound velocity",
        nc.UNITS_ATTR: "m/s",
    },
    ContentType.PRESSURE: {
        nc.STANDARD_NAME_ATTR: "pressure",
        nc.UNITS_ATTR: "bar",
    },
    ContentType.TEMPERATURE: {
        nc.STANDARD_NAME_ATTR: "temperature",
        nc.UNITS_ATTR: "deg C",
    },
    ContentType.CONDUCTIVITY: {
        nc.STANDARD_NAME_ATTR: "conductivity",
        nc.UNITS_ATTR: "S/m",
    },
    ContentType.PH: {
        nc.STANDARD_NAME_ATTR: "pH",
    },
    ContentType.REDOX: {
        nc.STANDARD_NAME_ATTR: "redox",
        nc.UNITS_ATTR: "Volt",
    },
}
# NetCDF Variable definition (variable name, attributes) for each ContentType
VAR_NAME_FOR_CONTENT_TYPE: Dict[ContentType, str] = {
    ContentType.TIMESTAMP: SENSOR_VAR_TIME,
    ContentType.DATETIME: SENSOR_VAR_TIME,
    ContentType.LATITUDE: SENSOR_VAR_LATITUDE,
    ContentType.LONGITUDE: SENSOR_VAR_LONGITUDE,
    ContentType.SPEED: SENSOR_VAR_GND_SPEED,
    ContentType.HEADING: SENSOR_VAR_HEADING,
    ContentType.DEPTH: SENSOR_VAR_DEPTH,
    ContentType.TURBIDITY: SENSOR_VAR_TURBIDITY,
    ContentType.REDOX: SENSOR_VAR_REDOX,
    ContentType.SALINITY: SENSOR_VAR_SALINITY,
    ContentType.SOUND_VELOCITY: SENSOR_VAR_SOUND_VELOCITY,
    ContentType.PRESSURE: SENSOR_VAR_PRESSURE,
    ContentType.TEMPERATURE: SENSOR_VAR_TEMPERATURE,
    ContentType.CONDUCTIVITY: SENSOR_VAR_CONDUCTIVITY,
    ContentType.PH: SENSOR_VAR_PH,
}
