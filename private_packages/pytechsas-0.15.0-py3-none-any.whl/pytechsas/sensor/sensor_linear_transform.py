#! /usr/bin/env python3
# coding: utf-8

import logging
import os
import shutil
from typing import List

import xarray as xr

import pytechsas.sensor.constant_mapping as cm
import pytechsas.sensor.sensor_file as su
from pytechsas.sensor.techsas_file import add_history

logger = logging.getLogger(__name__)


def apply_linear_transform(
    i_path: str,
    o_path: str,
    layers: List[str],
    a: float = 1.0,  # Multiplicator
    b: float = 0.0,  # Adder
):
    """
    Apply a linear transform to selected layers in a dataset.

    The transformation follows the formula: new_value = old_value * a + b

    Args:
        i_path: Path to input NetCDF file
        o_path: Path to output NetCDF file
        layers: List of variable names to transform
        a: Multiplicative factor (default: 1.0)
        b: Additive offset (default: 0.0)
    """
    if not os.path.exists(i_path):
        logger.error(f"Input file {i_path} does not exist. Nothing to do.")
        return

    # Copy input to output first
    if not os.path.exists(o_path) or not os.path.samefile(i_path, o_path):
        logger.info(f"Copying {i_path} to {o_path}")
        try:
            shutil.copy2(i_path, o_path)
        except PermissionError:
            logger.error(
                f"ERROR: Cannot access file '{i_path}'. "
                "The file is currently locked by another process or application. "
                "Please close any programs that may have this file open and try again."
            )
            return

    logger.info(f"Opening dataset: {i_path}")
    with xr.open_dataset(i_path) as in_ds:
        # Apply linear transform on dataset
        out_ds = apply_linear_transform_on_ds(in_ds, layers, a, b)

        if len(out_ds.data_vars) > 0:
            # Save output
            _add_history(in_ds, out_ds, a, b)
            out_ds.to_netcdf(o_path, mode="a", engine="netcdf4", format="NETCDF4")
            logger.info(f"Transformed dataset saved to: {o_path}")
        else:
            logger.warning("No valid layers found for transformation.")


def apply_linear_transform_on_ds(
    ds: xr.Dataset,
    layers: List[str],
    a: float = 1.0,
    b: float = 0.0,
) -> xr.Dataset:
    """
    Apply linear transformation to specified variables in the dataset.
    """
    result = xr.Dataset()

    for layer in layers:
        if layer in ds.data_vars:
            logger.info(f"Applying transform to layer: {layer} (v * {a} + {b})")
            result[layer] = ds[layer] * a + b
        else:
            logger.warning(f"Layer '{layer}' not found in dataset. Skipping.")

    return result


def _add_history(in_ds: xr.Dataset, out_ds: xr.Dataset, a: float, b: float):
    """
    Add history attribute to track the transformation applied.
    """
    add_history(
        origin_ds=in_ds,
        new_ds=out_ds,
        module_name=os.path.basename(__file__),
        history_info=(f"Linear transform ( v * {a} + {b} )"),
    )
