from functools import partial
from typing import Callable

import pandas as pd

from pytechsas.sensor.sensor_constant import ContentType


def _normalize_decimal(value: str, decimal_point: str) -> str:
    """
    Normalize decimal separator to standard dot notation.

    Args:
        value: String value potentially containing a custom decimal separator
        decimal_point: The decimal separator used in the data (e.g., ',' or '.')

    Returns:
        String with normalized decimal separator (dot)
    """
    if decimal_point != ".":
        return value.replace(decimal_point, ".")
    return value


def _make_float_converter(_, decimal_point: str) -> Callable[[str], float]:
    """
    Create a string to float converter that handles custom decimal separators.

    Args:
        fmt: Format string (unused but kept for API consistency)
        decimal_point: Decimal separator character (e.g., ',' or '.')

    Returns:
        Converter function that returns float or NaN on error
    """

    def converter(csv_value: str) -> float:
        normalized = _normalize_decimal(csv_value, decimal_point)
        return pd.to_numeric(normalized, errors="coerce", downcast="float")

    return converter


def _make_depth_converter(fmt: str, decimal_point: str) -> Callable[[str], float]:
    """
    Create a depth converter that handles custom decimal separators.
    Negates values if format is NEGATIVE_BELOW_SURFACE.

    Args:
        fmt: Depth format ('NEGATIVE_BELOW_SURFACE' or other)
        decimal_point: Decimal separator character

    Returns:
        Converter function for depth values
    """
    if fmt == "NEGATIVE_BELOW_SURFACE":

        def converter(csv_value: str) -> float:
            normalized = _normalize_decimal(csv_value, decimal_point)
            return -pd.to_numeric(normalized, errors="coerce", downcast="float")

    else:

        def converter(csv_value: str) -> float:
            normalized = _normalize_decimal(csv_value, decimal_point)
            return pd.to_numeric(normalized, errors="coerce", downcast="float")

    return converter


def _converter_datetime_with_unit(csv_value: str | pd.Series, unit: str) -> int | pd.Series:
    """
    Convert datetime value to nanoseconds since Unix epoch (1970-01-01).

    Args:
        csv_value: Numeric timestamp as string or Series
        unit: Time unit ('s', 'ms', 'us', 'ns')

    Returns:
        Nanoseconds since epoch as int, or Series of timestamps
    """
    numeric_value = float(csv_value) if isinstance(csv_value, str) else csv_value
    pd_datetime = pd.to_datetime(numeric_value, unit=unit)
    return pd_datetime.value if isinstance(csv_value, str) else pd_datetime


def _converter_datetime_since_2000(csv_value: str | pd.Series) -> int | pd.Series:
    """
    Convert datetime in seconds since 2000-01-01 to nanoseconds since Unix epoch.

    Args:
        csv_value: Seconds since 2000-01-01 as string or Series

    Returns:
        Nanoseconds since Unix epoch as int, or Series of timestamps
    """
    numeric_value = float(csv_value) if isinstance(csv_value, str) else csv_value
    pd_datetime = pd.to_datetime(
        numeric_value,
        unit="s",
        origin=pd.Timestamp("2000-01-01"),
    )
    return pd_datetime.value if isinstance(csv_value, str) else pd_datetime


def _converter_datetime_with_format(csv_value: str | pd.Series, fmt: str) -> int | pd.Series:
    """
    Convert datetime string with specific format to nanoseconds since Unix epoch.

    Args:
        csv_value: Datetime string or Series
        fmt: Datetime format string (e.g., '%Y-%m-%d %H:%M:%S')

    Returns:
        Nanoseconds since Unix epoch as int, or Series of timestamps
    """
    pd_datetime = pd.to_datetime(csv_value, format=fmt)
    return pd_datetime.value if isinstance(csv_value, str) else pd_datetime


def make_timestamp_converter(fmt: str | None) -> Callable:
    """
    Create a timestamp converter based on the specified format.

    Args:
        fmt: Timestamp format:
            - 's', 'ms', 'us', 'ns': Unix timestamp in specified unit
            - 's_2000': Seconds since 2000-01-01
            - Other string: Custom datetime format (e.g., '%Y-%m-%d')
            - None: Default to ISO8601 format

    Returns:
        Converter function for timestamp values
    """
    if fmt in ["s", "ms", "us", "ns"]:
        return partial(_converter_datetime_with_unit, unit=fmt)
    elif fmt == "s_2000":
        return _converter_datetime_since_2000
    elif fmt:
        return partial(_converter_datetime_with_format, fmt=fmt)
    else:
        return partial(_converter_datetime_with_format, fmt="ISO8601")


def get_converter(content_type: ContentType, fmt: str, decimal_point: str) -> Callable | None:
    """
    Get the appropriate converter function for a given content type.

    Args:
        content_type: Type of sensor data (e.g., DEPTH)
        fmt: Format specification for the content type
        decimal_point: Decimal separator used in CSV (e.g., ',' or '.')

    Returns:
        Converter function suitable for pandas.read_csv converters parameter
    """
    if content_type in [
        ContentType.TIMESTAMP,
        ContentType.DATETIME,
        ContentType.DATE,
        ContentType.TIME,
        ContentType.LATITUDE,
        ContentType.LONGITUDE,
    ]:
        return None

    if content_type == ContentType.DEPTH:
        return _make_depth_converter(fmt, decimal_point)

    return _make_float_converter(fmt, decimal_point)
