# Common constants for NetCDF files

# attributes
LONG_NAME = "long_name"
UNITS = "units"
HISTORY = "history"

# Units
DEGREE = "degree"
DEGREES_NORTH = "degrees_north"
DEGREES_EAST = "degrees_east"
METER_SECONDS = "m/s"


# Variables attributes
STANDARD_NAME_ATTR = "standard_name"
UNITS_ATTR = "units"
LONG_NAME_ATTR = "long_name"
VALID_RANGE_ATTR = "valid_range"
VALID_MIN = "valid_min"
CALENDAR_ATTR = "calendar"
COMMENT_ATTR = "comment"

# Variables definitions
VAR_CRS = "crs"

VAR_LONGITUDE_STANDARD_NAME = "longitude"
VAR_LONGITUDE_LONG_NAME = "longitude"
VAR_LONGITUDE_UNITS = DEGREES_EAST
VAR_LONGITUDE_VALID_RANGE = [-180.0, 180.0]

VAR_LATITUDE_STANDARD_NAME = "latitude"
VAR_LATITUDE_LONG_NAME = "latitude"
VAR_LATITUDE_UNITS = DEGREES_NORTH
VAR_LATITUDE_VALID_RANGE = [-90.0, 90.0]

VAR_HEADING_STANDARD_NAME = "heading"
VAR_HEADING_LONG_NAME = "heading(true)"
VAR_HEADING_UNITS = DEGREE
VAR_HEADING_VALID_RANGE = [0.0, 360.0]

VAR_GND_SPEED_STANDARD_NAME = "speed_wrt_ground"
VAR_GND_SPEED_LONG_NAME = "speed over ground"
VAR_GND_SPEED_UNITS = METER_SECONDS
VAR_GND_SPEED_VALID_MIN = 0.0

VAR_GND_COURSE_STANDARD_NAME = "course"
VAR_GND_COURSE_LONG_NAME = "course over ground"
VAR_GND_COURSE_UNITS = DEGREE
VAR_GND_COURSE_VALID_RANGE = [0.0, 360.0]
