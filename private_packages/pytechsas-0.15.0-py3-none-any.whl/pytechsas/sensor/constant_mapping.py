import logging
from dataclasses import dataclass

import xarray as xr

import pytechsas.sensor.sensor_constant as sc
import pytechsas.sensor.techsas_constant as tc

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class VariableNames:
    """
    Dataclass to hold variable names for TECHSAS or Sensor-netCDF files.
    """

    VAR_TIME: str
    VAR_LATITUDE: str
    VAR_LONGITUDE: str
    VAR_HEADING: str
    VAR_GND_SPEED: str
    VAR_GND_COURSE: str
    VAR_QUALITY_FLAG: str


# Instance of VariableNames for TECHSAS files
TECHSAS_VAR_NAMES = VariableNames(
    VAR_TIME=tc.TECHSAS_TIME,
    VAR_LONGITUDE=tc.TECHSAS_LONGITUDE,
    VAR_LATITUDE=tc.TECHSAS_LATITUDE,
    VAR_HEADING=tc.TECHSAS_HEADING,
    VAR_GND_SPEED=tc.TECHSAS_GND_SPEED,
    VAR_GND_COURSE=tc.TECHSAS_GND_COURSE,
    VAR_QUALITY_FLAG=tc.TECHSAS_STATUS,
)
# Instance of VariableNames for Sensor-netCDF files
SENSOR_VAR_NAMES = VariableNames(
    VAR_TIME=sc.SENSOR_VAR_TIME,
    VAR_LONGITUDE=sc.SENSOR_VAR_LONGITUDE,
    VAR_LATITUDE=sc.SENSOR_VAR_LATITUDE,
    VAR_HEADING=sc.SENSOR_VAR_HEADING,
    VAR_GND_SPEED=sc.SENSOR_VAR_GND_SPEED,
    VAR_GND_COURSE=sc.SENSOR_VAR_GND_COURSE,
    VAR_QUALITY_FLAG=sc.SENSOR_VAR_QUALITY_FLAG,
)


def guess_var_names(ds: xr.Dataset) -> VariableNames:
    """Return variable names according to file convention"""
    var_names = TECHSAS_VAR_NAMES
    if sc.CONVENTIONS in ds.attrs and ds.attrs[sc.CONVENTIONS] == sc.CONVENTIONS_VALUE:
        logger.info("Sensor-netCDF file detected")
        var_names = SENSOR_VAR_NAMES
    else:
        logger.info("TECHSAS file detected")

    return var_names
