# Specific constants for TECHSAS NetCDF files

import pytechsas.sensor.netcdf_constant as nc

# attributes
LONG_NAME = nc.LONG_NAME
UNITS = nc.UNITS
HISTORY = nc.HISTORY
FIRST_FRAME_DATE = "firstframetime"
LAST_FRAME_DATE = "lastframetime"
CREATION_TIME = "creationtime"

# variables
TECHSAS_TIME = "time"
TECHSAS_LONGITUDE = "lon"
TECHSAS_LONGITUDE_2 = "long"
TECHSAS_LATITUDE = "lat"
TECHSAS_HEADING = "heading"
TECHSAS_SPEED = "speed"  # Deprecated speed variable (used by previous version of "Apply Navigation")
TECHSAS_GND_SPEED = "speed_over_ground"
TECHSAS_GND_SPEED_2 = "gndspeed"  # Speed variable of .nav, .gps and .subnav TECHSAS files
TECHSAS_GND_COURSE = "gndcourse"
TECHSAS_ALTITUDE = "altitude"
TECHSAS_ALTITUDE_2 = "alt"
TECHSAS_MAG = "mag"
TECHSAS_GRAVITY = "gravity"
TECHSAS_STATUS = "status"
TECHSAS_MODE = "mode"
TECHSAS_DEPTH = "depth"
