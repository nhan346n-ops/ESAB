#! /usr/bin/env python3
# coding: utf-8

import logging
import os
import shutil
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

import numpy as np
import xarray as xr

import pytechsas.sensor.constant_mapping as cm
from pytechsas.sensor.quality_flag import initialize_and_merge_quality_flags
from pytechsas.sensor.techsas_file import add_history

logger = logging.getLogger(__name__)


class Comparator(Enum):
    """Enumeration of all possible comparison operators for filters."""

    BETWEEN = "between ( >= x <=)"
    LESS = "less than (<=x)"
    GREATER = "more than (>=x)"
    EQUAL = "equal"


@dataclass
class Filter:
    """
    Represents a single filter criterion with a variable, comparator, and operands.

    Attributes:
        variable: The name of the variable to filter on
        comparator: The comparison operator to apply
        operand1: The first operand (always used)
        operand2: The second operand (only used with BETWEEN comparator)
    """

    variable: str
    comparator: Comparator
    operand1: float
    operand2: Optional[float] = None

    def matches_array(self, values: np.ndarray) -> np.ndarray:
        """
        Checks if the given array of values matches this filter criterion.

        Args:
            values: Array of values to test

        Returns:
            Boolean array indicating which values satisfy the filter condition
        """
        # Create a mask with False for NaN values
        valid_mask = ~np.isnan(values)
        result = np.zeros_like(values, dtype=bool)

        if self.comparator == Comparator.BETWEEN:
            result[valid_mask] = (values[valid_mask] >= self.operand1) & (values[valid_mask] <= self.operand2)
            logger.info(f"Number values between {self.operand1} and {self.operand2} : {np.sum(result)}")
        elif self.comparator == Comparator.LESS:
            result[valid_mask] = values[valid_mask] <= self.operand1
            logger.info(f"Number values < {self.operand1} : {np.sum(result)}")
        elif self.comparator == Comparator.GREATER:
            result[valid_mask] = values[valid_mask] >= self.operand1
            logger.info(f"Number values > {self.operand1} : {np.sum(result)}")
        elif self.comparator == Comparator.EQUAL:
            result[valid_mask] = np.isclose(values[valid_mask], self.operand1)
            logger.info(f"Number values == {self.operand1} : {np.sum(result)}")

        return result

    @classmethod
    def from_dict(cls, data: dict) -> "Filter":
        """
        Creates a Filter instance from a dictionary.

        Args:
            data: Dictionary with filter data

        Returns:
            A new Filter instance
        """
        return cls(
            variable=data["variable"],
            comparator=Comparator[data["comparator"]],
            operand1=data["operand1"],
            operand2=data.get("operand2"),
        )


@dataclass
class FilterDescription:
    """
    Describes a complete filter configuration with multiple criteria.
    Used to determine quality flag values based on variable comparisons.

    Attributes:
        or_operator: When True, quality flag is set if at least one filter criterion is met.
                     When False, all filter criteria must be met (AND operator).
        filters: List of filter criteria to evaluate
        value: The quality flag value to set when filter conditions are satisfied
    """

    or_operator: bool = False
    filters: List[Filter] = field(default_factory=list)
    value: bool = True

    def evaluate_array(self, variable_values: Dict[str, np.ndarray]) -> np.ndarray:
        """
        Evaluates whether the given variable arrays satisfy the filter conditions.

        Args:
            variable_values: Dictionary mapping variable names to their numpy arrays

        Returns:
            Boolean array indicating which indices satisfy the conditions
        """
        if not self.filters:
            return np.array([], dtype=bool)

        # Get the length from the first available variable
        length = None
        for var_name in variable_values:
            if variable_values[var_name] is not None:
                length = len(variable_values[var_name])
                break

        if length is None:
            return np.array([], dtype=bool)

        # Evaluate each filter
        filter_results = []
        for filter_obj in self.filters:
            if filter_obj.variable in variable_values:
                logger.info(f"Processing variable '{filter_obj.variable}'")
                values = variable_values[filter_obj.variable]
                filter_results.append(filter_obj.matches_array(values))
            else:
                # If variable not found, filter doesn't match
                logger.warning(f"Variable '{filter_obj.variable}' not found in dataset")
                filter_results.append(np.zeros(length, dtype=bool))

        if not filter_results:
            return np.zeros(length, dtype=bool)

        # Combine results based on operator
        if self.or_operator:
            # OR operator: at least one filter must match
            result = np.zeros(length, dtype=bool)
            for fr in filter_results:
                result |= fr
            return result
        else:
            # AND operator: all filters must match
            result = np.ones(length, dtype=bool)
            for fr in filter_results:
                result &= fr
            return result

    @classmethod
    def from_dict(cls, data: dict) -> "FilterDescription":
        """
        Creates a FilterDescription instance from a dictionary.

        Args:
            data: Dictionary with filter description data

        Returns:
            A new FilterDescription instance
        """
        filters_data = data.get("filters", [])
        filters = [Filter.from_dict(f) for f in filters_data]

        return cls(or_operator=data.get("or_operator", False), filters=filters, value=data.get("value", True))


def apply_filter(
    i_path: str,
    o_path: str,
    filters: Dict,
):
    """Apply filters to NetCDF file and save result.

    Args:
        i_path: Input NetCDF file
        o_path: Output NetCDF file
        filters: FilterDescription containing filters to apply
    """
    if not os.path.exists(i_path):
        logger.error(f"Input file {i_path} does not exist. Nothing to do.")
        return

    # Copy input to output first
    if not os.path.exists(o_path) or not os.path.samefile(i_path, o_path):
        logger.info(f"Copying {i_path} to {o_path}")
        shutil.copy(i_path, o_path)

    # Parse filter description config
    filter_desc = FilterDescription.from_dict(filters)

    if filter_desc.filters is None or len(filter_desc.filters) == 0:
        logger.warning("No filters provided, nothing to do.")
        return

    # Open dataset and apply filters
    logger.info(f"Opening dataset: {i_path}")
    with xr.open_dataset(i_path) as in_ds:
        quality_flag_ds = apply_filter_on_dataset(in_ds, filter_desc)

        # Save filtered data
        if quality_flag_ds is not None and len(quality_flag_ds.data_vars) > 0:
            _add_history(in_ds, quality_flag_ds, i_path, filter_desc)
            logger.info("Writing filtered dataset to output file")
            quality_flag_ds.to_netcdf(o_path, mode="a")
            logger.info(f"Filtering completed. Result saved to: {o_path}")


def apply_filter_on_dataset(
    ds: xr.Dataset,
    filters: FilterDescription,
) -> xr.Dataset:
    """Apply filters on xarray Dataset.

    Args:
        ds: Input dataset
        filters: Filters to apply

    Returns:
        Dataset containing updated quality flag variable
    """

    # Get variable names from file
    var_names = cm.guess_var_names(ds)

    # Get time dimension length
    time_data = ds[var_names.VAR_TIME]
    data_length = len(time_data)

    # Initialize quality flags mask (True = valid by default)
    quality_flags_mask = np.full(data_length, dtype=bool, fill_value=True)

    # Apply filters to update the mask
    _apply_filter_quality_flags_mask(ds, quality_flags_mask, filters)

    quality_flags = initialize_and_merge_quality_flags(
        ds=ds, quality_flags_var_name=var_names.VAR_QUALITY_FLAG, quality_flags_mask=quality_flags_mask
    )

    # Create output dataset with updated quality flag
    quality_flag_ds = xr.Dataset()
    quality_flag_ds[var_names.VAR_QUALITY_FLAG] = quality_flags

    return quality_flag_ds


def _apply_filter_quality_flags_mask(
    ds: xr.Dataset, quality_flags_mask: np.ndarray, filters: FilterDescription
) -> None:
    """
    Apply filters on dataset variables and update the quality flags mask.

    The mask is updated in-place. When filter conditions are met:
    - If filters.value is True, the mask is set to True (valid)
    - If filters.value is False, the mask is set to False (invalid)

    Args:
        ds: Input dataset containing the variables
        quality_flags_mask: Boolean mask to update (modified in-place)
        filters: FilterDescription containing the filters to apply
    """
    if not filters.filters:
        logger.warning("No filters to apply")
        return

    # Extract variable data arrays
    variable_values = {}
    for filter_obj in filters.filters:
        var_name = filter_obj.variable
        if var_name in ds:
            variable_values[var_name] = ds[var_name].values
        else:
            logger.warning(f"Variable '{var_name}' not found in dataset")

    if not variable_values:
        logger.error("None of the filter variables found in dataset")
        return

    # Evaluate filters on the dataset
    filter_match = filters.evaluate_array(variable_values)

    # Update mask where filters match
    # If filters.value is True: set mask to True where conditions are met (mark as valid)
    # If filters.value is False: set mask to False where conditions are met (mark as invalid)
    quality_flags_mask[filter_match] = filters.value

    # Log statistics
    num_matched = np.sum(filter_match)
    num_total = len(filter_match)
    operator_str = "OR" if filters.or_operator else "AND"
    logger.info(
        f"Filter applied ({operator_str} operator): {num_matched}/{num_total} points matched, "
        f"quality flag set to {'Valid' if filters.value else 'Invalid'}"
    )


def _add_history(in_ds: xr.Dataset, out_ds: xr.Dataset, i_path: str, filters: FilterDescription):
    """
    Add history attribute to track the filters applied.

    Args:
        in_ds: Input dataset
        out_ds: Output dataset
        i_path: Input file path
        filters: FilterDescription that was applied
    """
    # Build filter description for history
    operator_str = "OR" if filters.or_operator else "AND"
    filter_descriptions = []
    for f in filters.filters:
        if f.comparator == Comparator.BETWEEN:
            desc = f"{f.variable} {f.comparator.name} [{f.operand1}, {f.operand2}]"
        else:
            desc = f"{f.variable} {f.comparator.name} {f.operand1}"
        filter_descriptions.append(desc)

    filters_str = f" {operator_str} ".join(filter_descriptions)
    value_str = "Valid" if filters.value else "Invalid"

    add_history(
        origin_ds=in_ds,
        new_ds=out_ds,
        module_name=os.path.basename(__file__),
        history_info=(
            f"Data filtered from {os.path.basename(i_path)}: " f"Quality flag set to {value_str} where ({filters_str})"
        ),
    )
