import csv
import logging as log
import os
from datetime import datetime
from enum import Enum
from typing import List, Tuple, Union

import numpy as np
import pandas as pd
import xarray as xr
from numpy import ma

import pytechsas.sensor.constant_mapping as cm
from pytechsas.sensor.quality_flag import (
    filter_dataset_by_quality,
    initialize_and_merge_quality_flags,
)

logger = log.getLogger()


class AnomalyType(str, Enum):
    """Enumeration of all possible anomaly types."""

    DUPLICATE = "duplicate"
    LEAPS_BACK = "leaps_back"
    INTERRUPTION = "interruption"
    INVALID_POSITION = "invalid_position"


class Anomaly:
    """
    This class represents an anomaly (error, invalid data...) in TECHSAS file.
    """

    def __init__(
        self,
        anomaly: AnomalyType,
        index: int,
        time: datetime,
        description: str,
        latitude: float = None,
        longitude: float = None,
        file: str = None,
    ):
        self.anomaly = anomaly
        self.index = index
        self.time = time
        self.description = description
        self.latitude = latitude
        self.longitude = longitude
        self.file = file

    def __str__(self) -> str:
        return str(self.__dict__)

    def log(self) -> str:
        return f"[{self.index}] {self.anomaly} ({self.description})"


def __check_duplicates__(time_arr: ma.MaskedArray) -> List[Anomaly]:
    """
    Identifies duplicated time values.
    @param time_arr: masked time values
    @return: a list of Anomaly
    """
    logger.info("Check duplicates...")
    result = []

    # Work only on unmasked values
    compressed_time = time_arr.compressed()
    valid_indices = np.where(~time_arr.mask)[0]

    unique_ar, count = np.unique(compressed_time, return_counts=True)
    duplicates = unique_ar[count > 1]

    for duplicated_time in duplicates:
        # Find indices in compressed array
        dup_indexes_compressed = np.where(compressed_time == duplicated_time)[0]
        # Convert to original array indices
        dup_indexes = valid_indices[dup_indexes_compressed]

        for i in dup_indexes:
            desc = f"Duplicated time {duplicated_time} at indexes : {dup_indexes}"
            result.append(Anomaly(AnomalyType.DUPLICATE, i, duplicated_time, desc))

    logger.info("No duplicate found." if len(result) == 0 else f"{len(result)} duplicate(s) found.")
    return result


def __check_leaps_back__(time_arr: ma.MaskedArray) -> List[Anomaly]:
    """
    Identifies leaps back in time array.
    @param time_arr: masked time values
    @return: a list of Anomaly
    """
    logger.info("Check leaps back...")
    result = []

    # Work only on unmasked values
    compressed_time = time_arr.compressed()
    valid_indices = np.where(~time_arr.mask)[0]

    # Calculate differences on compressed values
    back_arr = np.where(np.diff(compressed_time) < pd.Timedelta(0))[0]

    for i in back_arr:
        # Convert to original array indices
        orig_idx = valid_indices[i]
        orig_idx_next = valid_indices[i + 1]

        desc = f"leaps back between indexes {orig_idx} and {orig_idx_next} :  {time_arr[orig_idx]} => {time_arr[orig_idx_next]}"
        result.append(Anomaly(AnomalyType.LEAPS_BACK, orig_idx_next, time_arr[orig_idx_next], desc))

    logger.info("No leaps back found." if len(result) == 0 else f"{len(result)} leaps back found.")
    return result


def __check_interruptions__(time_arr: ma.MaskedArray, threshold: np.timedelta64) -> List[Anomaly]:
    """
    Identifies interruptions from time files.
    @param time_arr: masked time values
    @param threshold: an interruption is detected if the duration between two time values is over this delay
    @return: a list of Anomaly
    """
    logger.info(f"Check interruptions (threshold : {threshold})...")
    result = []

    # Work only on unmasked values
    compressed_time = time_arr.compressed()
    valid_indices = np.where(~time_arr.mask)[0]

    # Calculate differences on compressed values
    interruptions = np.where(np.diff(compressed_time) > threshold)[0]

    for i in interruptions:
        # Convert to original array indices
        orig_idx = valid_indices[i]
        orig_idx_next = valid_indices[i + 1]

        desc = f"Interruption between indexes {orig_idx} and {orig_idx_next} :  {time_arr[orig_idx]} => {time_arr[orig_idx_next]} : {pd.Timedelta(time_arr[orig_idx_next] - time_arr[orig_idx])}"
        result.append(Anomaly(AnomalyType.INTERRUPTION, orig_idx, time_arr[orig_idx], desc))

    logger.info("No interruption found." if len(result) == 0 else f"{len(result)} interruption(s) found.")
    return result


def __check_time__(time_arr: ma.MaskedArray, interruption_threshold_in_sec: int = 30) -> List[Anomaly]:
    """
    Finds anomalies in times.
    @return: a list of Anomaly
    """
    valid_count = np.sum(~time_arr.mask)
    logger.info(f"Check anomalies on {valid_count} valid time values (out of {len(time_arr)} total)...")
    result = []
    result.extend(__check_duplicates__(time_arr))
    result.extend(__check_leaps_back__(time_arr))

    if int(interruption_threshold_in_sec) > 0:
        result.extend(__check_interruptions__(time_arr, np.timedelta64(int(interruption_threshold_in_sec), "s")))
    else:
        logger.info("Check interruptions is ignored (threshold <= 0)")

    return result


def __check_position__(
    lat_arr: ma.MaskedArray, lon_arr: ma.MaskedArray, time_arr: ma.MaskedArray, check_latlon_0=False
) -> List[Anomaly]:
    """
    Finds invalid positions.
    @param lat_arr: masked latitude values
    @param lon_arr: masked longitude values
    @param time_arr: masked time values
    @param check_latlon_0 : Consider latitude/longitude values equal to 0 as anomalies
    @return: a list of Anomaly
    """
    valid_count = np.sum(~lat_arr.mask)
    logger.info(f"Check anomalies on {valid_count} valid positions (out of {len(lat_arr)} total)...")
    result: List[Anomaly] = []

    # Work on unmasked data
    valid_indices = np.where(~lat_arr.mask)[0]
    lat_data = lat_arr.data[valid_indices]
    lon_data = lon_arr.data[valid_indices]

    # Find invalid positions among valid data
    invalid_lat_indexes_compressed = np.where(
        (~np.isfinite(lat_data))
        | (-90 > lat_data)
        | (lat_data > 90)
        | ((check_latlon_0) & (lat_data == 0) & (lon_data == 0))
    )[0]
    invalid_lon_indexes_compressed = np.where(
        (~np.isfinite(lon_data))
        | (-180 > lon_data)
        | (lon_data > 180)
        | ((check_latlon_0) & (lat_data == 0) & (lon_data == 0))
    )[0]

    invalid_positions_compressed = np.sort(
        np.unique(np.concatenate((invalid_lat_indexes_compressed, invalid_lon_indexes_compressed)))
    )

    # Convert to original array indices
    invalid_positions = valid_indices[invalid_positions_compressed]

    for i in invalid_positions:
        lat = lat_arr[i]
        lon = lon_arr[i]
        desc = f"Invalid position at index {i} :  latitude = {lat} ; longitude = {lon}"
        result.append(Anomaly(AnomalyType.INVALID_POSITION, i, time_arr[i], desc, lat, lon))

    logger.info("No invalid position found." if len(result) == 0 else f"{len(result)} invalid(s) position.")
    return result


def __write_output_file__(anomalies: List[Anomaly], o_path: str, overwrite: bool = False):
    """
    Writes anomalies in CSV file.
    """
    if not overwrite and os.path.exists(o_path):
        logger.warning(f"Can't write output file : {o_path} already exists and overwrite option is false.")
        return
    with open(o_path, "w", newline="", encoding="utf-8") as csvfile:
        fieldnames = ["file", "index", "time", "latitude", "longitude", "anomaly", "description"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames, extrasaction="ignore", delimiter=";")
        writer.writeheader()
        writer.writerows([a.__dict__ for a in anomalies])


def check_anomalies_on_dataset(
    ds: xr.Dataset,
    interruption_threshold: int = 30,
    ignore_invalid_status=False,
    anomalies_processing="",
    check_latlon_0=False,
    var_names=cm.TECHSAS_VAR_NAMES,
) -> Tuple[xr.Dataset, List[Anomaly]]:
    """
    Researches anomalies in a TECHSAS file (duplicates, leap back, interruption, invalid position)
    @param ds: Dataset to check
    @param interruption_threshold: interruption delay
    @param ignore_invalid_status: if true, ignore data with invalid status
    @param anomalies_processing: if "Flag as invalid", edit input file status variable. if "Remove data", remove invalid data from input file
    @param check_latlon_0 : Consider latitude/longitude values equal to 0 as anomalies
    @return: Anomaly list
    """
    edit_input_file_status = anomalies_processing == "Flag as invalid"
    remove_invalid_data = anomalies_processing == "Remove data"

    anomalies: List[Anomaly] = []

    # get time array and create masked array
    time_data = ds[var_names.VAR_TIME].values
    status_arr = (
        ds[var_names.VAR_QUALITY_FLAG].values
        if var_names.VAR_QUALITY_FLAG in ds
        else np.zeros(len(time_data), dtype=np.int8)
    )

    # Create masked array for time
    if ignore_invalid_status and var_names.VAR_QUALITY_FLAG in ds:
        time_mask = status_arr != 0
    else:
        time_mask = np.zeros(len(time_data), dtype=bool)

    time_arr = ma.masked_array(time_data, mask=time_mask)

    # search anomalies in times
    anomalies.extend(__check_time__(time_arr, int(interruption_threshold)))

    if var_names.VAR_LATITUDE in ds and var_names.VAR_LONGITUDE in ds:
        lat_data = ds[var_names.VAR_LATITUDE].values
        lon_data = ds[var_names.VAR_LONGITUDE].values

        # Create masked arrays for lat/lon with same mask as time
        if ignore_invalid_status and var_names.VAR_QUALITY_FLAG in ds:
            position_mask = status_arr != 0
        else:
            position_mask = np.zeros(len(lat_data), dtype=bool)

        lat_arr = ma.masked_array(lat_data, mask=position_mask)
        lon_arr = ma.masked_array(lon_data, mask=position_mask)

        # add position to other anomalies
        for anomaly in anomalies:
            anomaly.latitude = lat_arr[anomaly.index] if not lat_arr.mask[anomaly.index] else None
            anomaly.longitude = lon_arr[anomaly.index] if not lon_arr.mask[anomaly.index] else None

        # search anomalies in positions
        anomalies.extend(__check_position__(lat_arr, lon_arr, time_arr, check_latlon_0))

    # Compute new status values
    if edit_input_file_status or remove_invalid_data:
        quality_flags_mask = np.full(len(time_data), dtype=bool, fill_value=True)
        quality_flags_mask[[a.index for a in anomalies if a.anomaly != AnomalyType.INTERRUPTION]] = False
        quality_flags = initialize_and_merge_quality_flags(
            ds=ds, quality_flags_var_name=var_names.VAR_QUALITY_FLAG, quality_flags_mask=quality_flags_mask
        )
        ds[var_names.VAR_QUALITY_FLAG] = quality_flags

        # Filter dataset using the mask DataArray
        if remove_invalid_data:
            logger.info("Filtering data...")
            ds = filter_dataset_by_quality(ds)

    return (ds, anomalies)


def __check_anomalies__(
    i_path: str,
    interruption_threshold: int = 30,
    ignore_invalid_status=False,
    anomalies_processing="",
    check_latlon_0=False,
) -> List[Anomaly]:
    """
    Researches anomalies in a TECHSAS file (duplicates, leap back, interruption, invalid position)
    @param i_path: file to check
    @param interruption_threshold: interruption delay
    @param ignore_invalid_status: if true, ignore data with invalid status
    @param anomalies_processing: if "Flag as invalid", edit input file status variable. if "Remove data", remove invalid data from input file
    @param: check_latlon_0 : Consider latitude/longitude values equal to 0 as anomalies
    @return: Anomaly list
    """
    anomalies: List[Anomaly] = []
    i_path_ds: xr.Dataset | None = None

    with xr.open_dataset(i_path) as i_path_ds:
        # Ensure dataset is loaded in memory before closing the file
        i_path_ds.load()

    # get variable names according to file convention
    var_names = cm.guess_var_names(i_path_ds)

    # check anomalies
    ds, anomalies = check_anomalies_on_dataset(
        i_path_ds, interruption_threshold, ignore_invalid_status, anomalies_processing, check_latlon_0, var_names
    )

    time_data = i_path_ds[var_names.VAR_TIME].values
    logger.info(f"Result : {len(anomalies)} anomalies on {len(time_data)}")
    if len(anomalies) > 50:
        logger.info("List of 50th first anomalies :")

    for anomaly in anomalies[0:50]:
        logger.info(anomaly.log())

    # add file name to anomalies
    for anomaly in anomalies:
        anomaly.file = os.path.basename(i_path)

    # Writing status in file
    if anomalies_processing in ["Flag as invalid", "Remove data"]:
        logger.info(f"Writing status in file {i_path}")
        ds.to_netcdf(path=i_path, mode="w")

    return anomalies


def sanity_check(
    i_paths: Union[List[str], str],
    o_path: str = None,
    overwrite: bool = False,
    interruption_threshold: int = 30,
    ignore_invalid_status=False,
    anomalies_processing="",
    check_latlon_0=False,
):
    """
    Applies sanity check : researches anomalies in time and position variables.
    @param i_paths: input file(s) to check.
    @param o_path: output CSV file path (.csv) (filled with result anomalies)
    @param overwrite: option to overwrite output file if already exist
    @param interruption_threshold: minimum delay to consider an interruption. 0 to ignore interruption
    @param ignore_invalid_status: if true, ignore data with invalid status
    @param anomalies_processing: if "Flag as invalid", edit input file status variable. if "Remove data", remove invalid data from input file
    @param: check_latlon_0 : Consider latitude/longitude values equal to 0 as anomalies
    """
    if isinstance(i_paths, str):
        i_paths = [i_paths]

    anomalies: List[Anomaly] = []
    for i_path in i_paths:
        anomalies.extend(
            __check_anomalies__(
                i_path=i_path,
                interruption_threshold=interruption_threshold,
                ignore_invalid_status=ignore_invalid_status,
                anomalies_processing=anomalies_processing,
                check_latlon_0=check_latlon_0,
            )
        )

    # save anomalies in output CSV file
    if o_path is not None and anomalies:
        __write_output_file__(anomalies, o_path, overwrite)
