"""
CSV to NetCDF Converter for Sensor Data

Converts CSV sensor data to CF-compliant NetCDF format. Handles datetime parsing,
navigation interpolation, and quality checks.
"""

import logging
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import xarray as xr

import pytechsas.sensor.constant_mapping as cm
import pytechsas.sensor.netcdf_constant as nc
import pytechsas.sensor.sensor_constant as sc
import pytechsas.sensor.sensor_file as su
from pytechsas.sensor.sensor_converters import get_converter, make_timestamp_converter
from pytechsas.sensor.techsas_apply_navigation import (
    ApplyNavigationData,
    get_interpolated_nav,
)
from pytechsas.sensor.techsas_file import add_history
from pytechsas.sensor.techsas_sanity_check import Anomaly, check_anomalies_on_dataset

logger = logging.getLogger(__name__)


@dataclass
class ColumnInfo:
    """Metadata for a single CSV column.

    Attributes:
        content_type: What this column contains (VALUE, TIMESTAMP, LATITUDE, etc.)
        format: Optional format string for parsing dates/times
    """

    content_type: sc.ContentType = sc.ContentType.VALUE
    format: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ColumnInfo":
        """Create ColumnInfo from dict."""
        return cls(content_type=sc.ContentType(data["content_type"]), format=data.get("format"))


@dataclass
class CsvDescription:
    """Complete description of CSV structure and parsing rules.

    Attributes:
        delimiter: Column separator (';', ',', '\t', etc.)
        decimal_point: Decimal separator ('.', ',')
        header_line: Optional 1-based index of header row
        first_data_line: 1-based index where data starts
        columns: Dict mapping column index to ColumnInfo
    """

    delimiter: str
    decimal_point: str
    header_line: int | None
    first_data_line: int
    columns: Dict[str, ColumnInfo]

    def get_column_index(self, content_type: sc.ContentType) -> Tuple[int, ColumnInfo] | None:
        """Find column index for a specific content type."""
        for col_index, col_info in self.columns.items():
            if col_info.content_type == content_type:
                return (int(col_index), col_info)
        return None

    @classmethod
    def from_dict(cls, data: dict) -> "CsvDescription":
        """Create CsvDescription from dict config."""
        columns = {col_num: ColumnInfo.from_dict(col_data) for col_num, col_data in data["columns"].items()}
        return cls(
            delimiter=data["delimiter"],
            decimal_point=data["decimal_point"],
            header_line=data.get("header_line"),
            first_data_line=data["first_data_line"],
            columns=columns,
        )


def convert(
    csv_path: str,
    netcdf_path: str,
    csv_description: Dict,
    nav: Optional[ApplyNavigationData] = None,
    sanity_check: bool = False,
    anomalies_processing: str = "Flag anomalies",
    check_latlon_0=False,
    interruption_threshold: int = 30,
    ignore_invalid_data: bool = False,
    cruise_identifier: str = "",
    cruise_name: str = "",
    sensor_name: str = "",
) -> List[Anomaly]:
    """Convert CSV file to CF-compliant NetCDF format.

    Main conversion workflow:
    1. Parse CSV structure from config
    2. Load CSV data
    3. Handle datetime columns
    4. Convert to xarray Dataset
    5. Apply navigation (optional)
    6. Run sanity checks (optional)
    7. Write NetCDF file

    Args:
        csv_path: Input CSV file path
        netcdf_path: Output NetCDF file path
        csv_description: Dict describing CSV structure
        nav: Optional navigation data for lat/lon interpolation
        sanity_check : True to perform sanity check on the data, False to skip it
        anomalies_processing: 'Flag anomalies', 'Remove anomalies'
        check_latlon_0: Treat lat/lon=0 as anomalies
        interruption_threshold: Max time gap (seconds) before data interruption
        cruise_identifier: Cruise/campaign ID for metadata
        cruise_name: Human-readable cruise name
        sensor_name: Sensor identifier (e.g., 'CTD-01')
    """
    # Parse CSV config
    csv_desc = CsvDescription.from_dict(csv_description)

    # Read header if present
    header_names = _read_header_line(csv_path, csv_desc)

    # Load CSV data
    df = _load_csv_data(csv_path, csv_desc, header_names)
    df = _clean_dataframe(df, csv_desc, ignore_invalid_data)
    logger.info(f"Successfully loaded data with shape {df.shape}")

    # Parse datetime columns and set as index
    _process_datetime_columns(df, csv_desc, header_names)

    # Convert to xarray Dataset
    ds = _convert_to_dataset(df, csv_desc, header_names)

    # Prepare lat/lon variables if nav will be applied
    if nav is not None:
        _add_lon_lat(ds)

    # Add geospatial reference system
    _add_crs_variable(ds)

    # Add metadata
    _add_metadata(ds, cruise_identifier, cruise_name, sensor_name)

    # Apply navigation interpolation
    if nav is not None:
        nav_ds = get_interpolated_nav(ds, nav, var_names=cm.SENSOR_VAR_NAMES)
        ds.update(nav_ds)

    # Run quality checks
    anomalies = []
    if sanity_check:
        ds, anomalies = check_anomalies_on_dataset(
            ds=ds,
            anomalies_processing=anomalies_processing,
            interruption_threshold=interruption_threshold,
            check_latlon_0=check_latlon_0,
            var_names=cm.SENSOR_VAR_NAMES,
        )

    _add_history(ds, csv_path)

    # Write NetCDF file
    su.write_dataset_to_netcdf(ds, netcdf_path)

    return anomalies


def _add_lon_lat(ds: xr.Dataset) -> None:
    """Add lat/lon variables initialized with NaN.

    These will be filled later by navigation interpolation.
    """
    for var_name, content_type in zip(
        [sc.SENSOR_VAR_LATITUDE, sc.SENSOR_VAR_LONGITUDE], [sc.ContentType.LATITUDE, sc.ContentType.LONGITUDE]
    ):
        if var_name not in ds:
            ds[var_name] = xr.DataArray(np.full(shape=ds[sc.SENSOR_VAR_TIME].shape, fill_value=np.nan, dtype=float))
            _configure_nc_var(ds[var_name], content_type)


def _get_nc_var_name(csv_desc: CsvDescription, str_idx: str, header_names: Optional[List[str]]):
    """Determine NetCDF variable name for a CSV column.

    Priority: standard name > CSV header > 'col_N' fallback
    """
    col_info = csv_desc.columns[str_idx]
    col_index = int(str_idx)
    # Use standard names for known content types
    if col_info.content_type in sc.VAR_NAME_FOR_CONTENT_TYPE:
        result = sc.VAR_NAME_FOR_CONTENT_TYPE[col_info.content_type]
        # Handle multiple columns with same content type by adding suffix
        suffix = 0
        for one_str_idx, one_col_info in csv_desc.columns.items():
            if int(one_str_idx) < col_index and one_col_info.content_type == col_info.content_type:
                suffix += 1

        return f"{result}_{suffix}" if suffix > 0 else result

    # Use CSV header name if available
    if header_names and col_index < len(header_names):
        # NetCDF use slash as group separator
        return header_names[col_index].replace("/", "_")

    # Fallback
    return f"col_{col_index}"


def _convert_to_dataset(df: pd.DataFrame, csv_desc: CsvDescription, header_names: Optional[List[str]]) -> xr.Dataset:
    """Convert DataFrame to xarray Dataset with CF attributes.

    Adds global metadata and configures all variables with proper attributes.
    """
    ds = xr.Dataset.from_dataframe(df)

    # Global metadata
    ds.attrs[sc.DATE_CREATED] = datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    ds.attrs[sc.CONVENTION_AUTHORITY] = sc.CONVENTION_AUTHORITY_VALUE
    ds.attrs[sc.CONVENTIONS] = sc.CONVENTIONS_VALUE

    # Configure time variable
    if sc.SENSOR_VAR_TIME in ds.variables:
        _configure_nc_var(ds[sc.SENSOR_VAR_TIME], sc.ContentType.TIMESTAMP)

    # Configure all data variables
    for col_idx, col_info in csv_desc.columns.items():
        var_name = _get_nc_var_name(csv_desc, col_idx, header_names)

        if var_name in ds.variables:
            _configure_nc_var(ds[var_name], col_info.content_type)

    return ds


def _add_metadata(ds: xr.Dataset, cruise_identifier: str = "", cruise_name: str = "", sensor_name: str = "") -> None:
    """Add cruise and sensor metadata to global attributes."""
    if cruise_identifier:
        ds.attrs[sc.CRUISE_IDENTIFIER] = cruise_identifier
    if cruise_name:
        ds.attrs[sc.CRUISE_NAME] = cruise_identifier
    if sensor_name:
        ds.attrs[sc.SENSOR_NAME] = sensor_name


def _read_header_line(csv_path: str, csv_desc: CsvDescription) -> List[str]:
    """Read header line from CSV to extract column names."""
    all_headers = []
    if csv_desc.header_line is not None:
        logger.info(f"Reading header from line {csv_desc.header_line}")

        with open(csv_path, "r", encoding="utf-8") as f:
            for i, line in enumerate(f):
                if i + 1 == csv_desc.header_line:
                    all_headers = [name.strip() for name in line.split(csv_desc.delimiter)]
                    break
            else:
                logger.warning(f"Header line {csv_desc.header_line} not found in file")
    else:
        logger.info("No header line specified, using default column names")

    return all_headers


def _load_csv_data(csv_path: str, csv_desc: CsvDescription, header_names: Optional[List[str]]) -> pd.DataFrame:
    """Load CSV data into DataFrame with type conversions.

    Creates custom converters for dates/times and applies proper column names.
    Removes rows containing NaN values and logs the cleaning statistics.
    """
    logger.info(f"Loading CSV data from {csv_path}")

    column_indices = [int(idx) for idx in csv_desc.columns.keys()]
    logger.debug(f"Parsing with 'delimiter'='{csv_desc.delimiter}'")
    logger.debug(f"Parsing with 'decimal'='{csv_desc.decimal_point}'")
    logger.debug(f"Parsing with 'skiprows'='{csv_desc.first_data_line}'")
    logger.debug(f"Parsing with 'usecols'='{column_indices}'")

    # Create converters for special column types
    converters = {}
    for col_index, col_info in csv_desc.columns.items():
        converter = get_converter(col_info.content_type, col_info.format, csv_desc.decimal_point)
        if converter:
            converters[int(col_index)] = converter

    # Generate column names
    names = []
    for str_idx in sorted(csv_desc.columns.keys(), key=int):
        names.append(_get_nc_var_name(csv_desc, str_idx, header_names))
    logger.info(f"Selected columns: {names}")

    # Load CSV
    all_chunk_df = []
    line_count = 0
    print(f"csv_desc.first_data_line : {csv_desc.first_data_line}")

    for chunk_df in pd.read_csv(
        csv_path,
        delimiter=csv_desc.delimiter,
        decimal=csv_desc.decimal_point,
        skiprows=max(csv_desc.first_data_line - 1, 0),
        names=names if names else None,
        usecols=column_indices,
        encoding="utf-8",
        converters=converters,
        chunksize=100_000,
    ):
        line_count += len(chunk_df)
        logger.info(f"{line_count} lines parsed")
        all_chunk_df.append(chunk_df)

    return pd.concat(all_chunk_df, ignore_index=True)


def _clean_dataframe(df: pd.DataFrame, csv_desc: CsvDescription, ignore_invalid_data: bool) -> pd.DataFrame:
    """Remove rows with NaN values"""
    logger.info(f"Loaded {len(df)} rows and {len(df.columns)} columns")

    nan_mask = df.isna().any(axis=1)
    nan_count = nan_mask.sum()

    if nan_count > 0:
        # Log detailed information about NaN occurrences
        logger.warning(f"{nan_count} conversion errors encountered")

        # Log first 10 NaN occurrences with row number and column name
        nan_occurrences = []

        # Find rows with NaN
        rows_with_nan = df[nan_mask]

        for idx, row in rows_with_nan.iterrows():
            # Find which columns have NaN in this row
            nan_columns = row[row.isna()].index.tolist()

            # Account for skiprows offset to get actual file line number
            actual_line_number = df.index.get_loc(idx) + csv_desc.first_data_line + 1

            for col_name in nan_columns:
                nan_occurrences.append((actual_line_number, col_name))

                # Stop after collecting 10 occurrences
                if len(nan_occurrences) >= 10:
                    break

            if len(nan_occurrences) >= 10:
                break

        # Log the occurrences
        for line_num, col_name in nan_occurrences:
            logger.warning(f"  - Line {line_num}, Column '{col_name}'")

        if nan_count > 10:
            logger.warning(f"  ... and {nan_count - 10} more conversion errors")

        # Remove rows with NaN
        if ignore_invalid_data:
            df = df.dropna()
            logger.warning(f"Removed {nan_count} rows with data errors, {len(df)} rows remaining")
    else:
        logger.info("No conversion errors detected in the data")

    return df


def _process_datetime_columns(df: pd.DataFrame, csv_desc: CsvDescription, header_names: Optional[List[str]]) -> None:
    """Parse datetime columns and set as DataFrame index.

    Handles:
    - Single TIMESTAMP column (already complete)
    - Single DATETIME column (already complete)
    - Separate DATE and TIME columns (combines them)
    - No datetime columns, raise an error
    """
    timestamp_values = None

    # Look TIMESTAMP column first
    for col_idx, col_info in csv_desc.columns.items():
        if col_info.content_type == sc.ContentType.TIMESTAMP:
            datetime_converter = make_timestamp_converter(col_info.format)
            timestamp_values = datetime_converter(df[sc.SENSOR_VAR_TIME])
            break

    # If no timestamp, look for DATETIME
    if timestamp_values is None:
        for col_idx, col_info in csv_desc.columns.items():
            if col_info.content_type == sc.ContentType.DATETIME:
                datetime_converter = make_timestamp_converter(col_info.format)
                timestamp_values = datetime_converter(df[sc.SENSOR_VAR_TIME])
                break

    # If no timestamp, try combining DATE and TIME columns
    if timestamp_values is None:
        date_values = None
        time_values = None

        for col_idx, col_info in csv_desc.columns.items():
            var_name = _get_nc_var_name(csv_desc, col_idx, header_names)

            if col_info.content_type == sc.ContentType.DATE:
                datetime_converter = make_timestamp_converter(col_info.format)
                date_values = datetime_converter(df[var_name])
                df.drop(columns=[var_name], inplace=True)

            elif col_info.content_type == sc.ContentType.TIME:
                datetime_converter = make_timestamp_converter(col_info.format)
                time_values = datetime_converter(df[var_name])
                df.drop(columns=[var_name], inplace=True)

        # Combine date and time
        if date_values is not None and time_values is not None:
            timestamp_values = date_values.dt.normalize() + (time_values - time_values.dt.normalize())

    # Set as index if we got timestamps
    if timestamp_values is not None:
        df[sc.SENSOR_VAR_TIME] = timestamp_values
        df.set_index(sc.SENSOR_VAR_TIME, inplace=True)
    else:
        raise ValueError("No date/time column specified")


def _add_crs_variable(ds: xr.Dataset) -> None:
    """Add CF-compliant CRS variable for geospatial data.

    Creates scalar variable with WGS84 (EPSG:4326) parameters and links
    all data variables to it via grid_mapping attribute.
    """
    # Only add if we have lat/lon
    if sc.SENSOR_VAR_LATITUDE in ds.variables and sc.SENSOR_VAR_LONGITUDE in ds.variables:
        ds[nc.VAR_CRS] = xr.DataArray(
            np.int32(0),
            attrs={
                "grid_mapping_name": "latitude_longitude",
                "longitude_of_prime_meridian": 0.0,
                "semi_major_axis": 6378137.0,
                "inverse_flattening": 298.257223563,
                "epsg_code": "EPSG:4326",
                "spatial_ref": "GEOGCS['WGS 84',DATUM['WGS_1984',SPHEROID['WGS 84',6378137,298.257223563,AUTHORITY['EPSG','7030']],AUTHORITY['EPSG','6326']],PRIMEM['Greenwich',0,AUTHORITY['EPSG','8901']],UNIT['degree',0.0174532925199433,AUTHORITY['EPSG','9122']],AUTHORITY['EPSG','4326']]",
            },
        )

        logger.info("Added CRS variable")

        # Link all data vars to CRS
        for var_name in ds.data_vars:
            if var_name not in [nc.VAR_CRS, sc.SENSOR_VAR_LATITUDE, sc.SENSOR_VAR_LONGITUDE]:
                ds[var_name].attrs["grid_mapping"] = nc.VAR_CRS
                logger.debug(f"Added grid_mapping='crs' to variable '{var_name}'")


def _configure_nc_var(data_array: xr.DataArray, content_type: sc.ContentType):
    """Configure CF-compliant attributes for a NetCDF variable.

    Applies standard CF attributes like units, standard_name, etc.
    """
    if content_type in sc.NC_VAR_ATTRIBUTES:
        var_def = sc.NC_VAR_ATTRIBUTES[content_type]
        for key, value in var_def.items():
            # Only apply CF-standard and SDN attributes
            if key in [
                nc.STANDARD_NAME_ATTR,
                nc.UNITS_ATTR,
                nc.LONG_NAME_ATTR,
                nc.VALID_RANGE_ATTR,
                nc.VALID_MIN,
                nc.COMMENT_ATTR,
            ] or key.startswith("sdn_"):
                logger.debug(f"Setting attribute '{key}' to '{value}' for variable '{data_array.name}'")
                data_array.attrs[key] = value

    if content_type != sc.ContentType.TIMESTAMP:
        data_array.attrs["content_type"] = content_type.value


def _add_history(ds: xr.Dataset, csv_path: str):
    """Add history attribute to track conversion provenance."""
    add_history(
        new_ds=ds, module_name=os.path.basename(__file__), history_info=(f"Convert from : {os.path.basename(csv_path)}")
    )
