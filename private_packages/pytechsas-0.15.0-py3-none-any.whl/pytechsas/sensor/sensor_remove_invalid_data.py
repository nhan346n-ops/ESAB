#! /usr/bin/env python3
# coding: utf-8

import logging
import os

import xarray as xr

import pytechsas.sensor.constant_mapping as cm
import pytechsas.sensor.sensor_file as su
from pytechsas.sensor.quality_flag import filter_dataset_by_quality
from pytechsas.sensor.techsas_file import add_history

logger = logging.getLogger(__name__)


def apply_remove(
    i_path: str,
    o_path: str,
    keep_quality_flag_variable=False,
):
    """Remove invalid data from NetCDF file based on quality_flag variable.

    Args:
        i_path: Input NetCDF file
        o_path: Output NetCDF file
        keep_quality_flag_variable: Keep quality_flag variable in output
    """
    if not os.path.exists(i_path):
        logger.error(f"Input file {i_path} does not exist. Nothing to do.")
        return

    logger.info(f"Opening dataset: {i_path}")
    with xr.open_dataset(i_path) as in_ds:
        var_names = cm.guess_var_names(in_ds)

        # Remove records where quality_flag is invalid
        out_ds = apply_remove_on_ds(in_ds, var_names)

        # Drop quality_flag variable if requested
        if not keep_quality_flag_variable and var_names.VAR_QUALITY_FLAG in in_ds:
            out_ds = out_ds.drop_vars(var_names.VAR_QUALITY_FLAG)

        # Save output
        _add_history(out_ds, i_path)
        su.write_dataset_to_netcdf(out_ds, o_path)


def apply_remove_on_ds(ds: xr.Dataset, var_names: cm.VariableNames) -> xr.Dataset:
    """Remove invalid data based on quality_flag variable.

    Args:
        ds: Input dataset
        var_names: Variable names mapping

    Returns:
        Dataset with only valid records
    """
    if var_names.VAR_QUALITY_FLAG in ds:
        logger.info("Removing invalid data based on quality_flag variable")
        return filter_dataset_by_quality(ds)

    logger.info("No quality_flag variable found, nothing to remove.")
    return ds


def _add_history(ds: xr.Dataset, i_path: str):
    """
    Add history attribute
    """
    add_history(
        new_ds=ds,
        module_name=os.path.basename(__file__),
        history_info=(f"Invalid data removed from {os.path.basename(i_path)}"),
    )
