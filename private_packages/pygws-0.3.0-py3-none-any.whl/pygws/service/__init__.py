"""
Module dedicated to providers of GWS services (typically Pyat).

Providers Suppliers can implement their own services (any Callable).
They will be executed on demand by GWS using the `execute` function in the `pygws.service.service_executor` submodule.

GWS optimizes the execution of services by pooling them.
This means that the service will be started in a python process and will wait for a signal (json document sent with RSocket) to execute the service.
Configure in GWS the execution of these services by indicating the `pygws.service.deferred_service_executor` submodule.
"""
