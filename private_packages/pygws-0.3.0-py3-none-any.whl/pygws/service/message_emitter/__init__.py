"""
Module providing message transmission functionalities in payload form.
"""
