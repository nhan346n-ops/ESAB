import json
import queue
from typing import Callable, Dict

from rsocket.helpers import utf8_decode

import pygws.service.execution_context as exec_ctx
from pygws.service import service_executor
from pygws.shared.gws_logger import logger
from pygws.shared.rsocket.payload_interpreters import PayloadInterpreter


class ServiceConfigurationInterpreter(PayloadInterpreter):
    """
    Payload interpreter, reacting to a service launch request.
    """

    def __init__(self, request_queue: queue.Queue[bytearray]):
        self.request_queue = request_queue

    def get_rsocket_route(self) -> str:
        """Route of payload"""
        return "run_service"

    async def process_payload(self, payload: bytearray) -> None:
        """Receive a bytearray on the configured route."""

        logger.debug("Service request received")
        logger.debug(f"Arguments : {utf8_decode(payload)}")

        # Just put the payload in the queue to trigger the execution of _process_request function
        self.request_queue.put(payload)

        # Leave this function as soon as possible to free the asyncio loop
        return None  # No answer expected by the client


def start_and_wait_signal(socket_port: int, service: Callable[[Dict], None]) -> None:
    logger.info("Starting a defered service")

    request_queue: queue.Queue[bytearray] = queue.Queue()

    def wait_for_request_in_queue():
        # Check every 5s if service is over. May happened when RSocket connection is lost
        while not exec_ctx.get_service_finished().is_set():
            try:
                payload = request_queue.get(timeout=5)
                arguments = json.loads(payload)
                service(arguments)
                return
            except queue.Empty:
                pass

    # Expecting the RSocket port.
    try:
        logger.info("Waiting for service parameters on Socket port %d", socket_port)

        service_executor.execute(
            socket_port=socket_port,
            service=wait_for_request_in_queue,
            payload_interpreters=[
                ServiceConfigurationInterpreter(request_queue),
                service_executor.CancelPayloadInterpreter(),
            ],
        )
        logger.info("Defered service stopped")

    except Exception:
        logger.exception("Error while running the defered service")
        raise
