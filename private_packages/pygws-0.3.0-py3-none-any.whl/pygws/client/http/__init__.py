"""
Module dedicated to the GWS client for communicating with the GWS server's HTTP API.
A GWS client can request configured services and jobs.
It can also request to launch a GWS service and obtain the results.
"""
