"""
Module dedicated to the GWS clients (typically Marvin).
Clients can make requests to HTTP API of GWS by using the submodule `pygws.client.http`.
Clients can communicate with a running GWS service and get results by using the submodule `pygws.client.rsocket`.
"""
