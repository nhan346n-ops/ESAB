class GwsError(Exception):
    """Exception raised by PyGws"""
