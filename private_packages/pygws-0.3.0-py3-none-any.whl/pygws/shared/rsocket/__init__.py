"""
Module defining the necessary components for managing the communication between a GWS client and a running GWS service using RSocket protocol.
  +-----------------+                                                                                              +-----------------+
  | GwsSocketClient |                                                                                              | GwsSocketClient |
  +-----------------+                                                                                              +-----------------+
  | +--------------+|              +------------+              +--------+              +------------+              |    Service GWS  |
  | |PayloadHandler|<----Payload-- |            | <--Payload-- |        | <--Payload-- |            | <--Payload-- |      (Pyat)     |
  | +--------------+|              |  Websocket |              |   GWS  |              | TCP socket |              |+--------------+ |
  |   GWS client    | --Payload--> |            | --Payload--> |        | --Payload--> |            |--Payload----->|PayloadHandler| |
  |    (Marvin)     |              +------------+              +--------+              +------------+              |+--------------+ |
  +-----------------+                                                                                              +-----------------+

In the above diagram:
- The GWS client creates a `GwsSocketClient` instance using a Websocket transport (provided by concrete class).
- The GWS service creates a `GwsSocketClient` instance using a TCP transport (provided by concrete class).
- Both GwsSocketClient instances use a `PayloadHandler` to manage the received payloads.
"""
