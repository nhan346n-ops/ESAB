import logging

logger = logging.getLogger("PyGws")
