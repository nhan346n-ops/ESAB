"""
Module name for modern netcdf file nvi format
These file have a .nvi.nc extension
"""
