"""
Class generated from model, do not change this code source as it might be erased by another code generation"""


import netCDF4 as nc

import numpy as np
# pylint: disable=import-error
# pylint: disable=E1101
# pylint: disable=R0904
# pylint: disable=C0305
# pylint: disable=C0302

from .nc_tools import find_type

DEFAULT_COMPRESSION_LIB = "zlib"
DEFAULT_COMPRESSION_LEVEL = 4


class RootGrp:
    @staticmethod
    def get_group_path():
        return "/"

    def create_group(self, parent_group: nc.Dataset,vlen_type_dict=None,**attributes):
        g = parent_group.createGroup(self.get_group_path())
        if vlen_type_dict is None:
            vlen_type_dict = {}

        #declare vlen types:
        for key, value in vlen_type_dict.items():
            vlen_type = g.createVLType(vlen_type_dict[key], key)
        if "Conventions" not in attributes:
            g.Conventions = "CF-1.7, ACDD-1.3"#A comma-separated list of the conventions followed in the file. Include the relevant CF and ACDD conventions (e.g. ”CF-1.7” and ”ACDD-1.3”).
        if "date_created" not in attributes:
            g.date_created = "null"#Timestamp of file creation in ISO8601:2004 extended format, including the time zone (e.g. 2017-05-06T20:21:35Z).
        if "nvi_convention_authority" not in attributes:
            g.nvi_convention_authority = "Ifremer"#Name of the organization managing and distributing the  navigation file convention. Currently Ifremer.
        if "nvi_convention_name" not in attributes:
            g.nvi_convention_name = "NVI convention name"#Formal name of this convention (i.e. ”NVI”).
        if "nvi_convention_version" not in attributes:
            g.nvi_convention_version = "1.1"#NVI version number in the form “major.minor”, where major and minor are non-negative integers.
        if "nvi_file_type" not in attributes:
            g.nvi_file_type = "null"#Type of NVI file. Possible values are: ‘NVI’, ‘NVI-CTD’, ‘NVI-CTD-CAST’, ‘NVI-CTD-PROFILE’, ‘NVI-CTD-PROFILE-CAST’, ‘NVI-CTD-PROFILE-CAST-PARSED’.
        if "nvi_file_type" not in attributes:
            g.nvi_file_type = "null"#Type of NVI file. Possible values are: ‘NVI’, ‘NVI-CTD’, ‘NVI-CTD-CAST’, ‘NVI-CTD-PROFILE’, ‘NVI-CTD-PROFILE-CAST’, ‘NVI-CTD-PROFILE-CAST-PARSED’.
        if "cruise_name" not in attributes:
            g.cruise_name = "Unknown Survey name"#Name of the survey. This is the name of the cruise or project.
        if "cruise_identifier" not in attributes:
            g.cruise_identifier = ""#Cruise Identifier of the cruise associated with this dataset. This is an alphanumeric code assigned to the cruise when publishing on national databases.
        if "platform_name" not in attributes:
            g.platform_name = "Unknown Platform name"#Name of the supporting platform. This is the name of the ship or platform.

        #write attributes passed as argument
        for key, value in attributes.items():
            g.setncattr(key, value)

        return g
    # Variables names
    ###
    #crs variable definition
    CRS_VNAME="crs"

    @staticmethod
    def CRS():
        return RootGrp.get_group_path()+"crs"

    def create_crs(self, group: nc.Dataset, missing_value=None, **attributes):
        """create variable crs"""
        v = group.createVariable(varname="crs", datatype=np.int32, dimensions=(), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "grid_mapping_name" not in attributes:
            v.grid_mapping_name  = "latitude_longitude"
        if "longitude_of_prime_meridian " not in attributes:
            v.longitude_of_prime_meridian  = np.float32(0.0)
        if "semi_major_axis " not in attributes:
            v.semi_major_axis  = np.float32(6378137)
        if "inverse_flattening" not in attributes:
            v.inverse_flattening = np.float32(298.257223563)
        if "crs_wkt" not in attributes:
            v.crs_wkt = "GEOGCS['WGS 84',DATUM['WGS_1984',SPHEROID['WGS 84',6378137,298.257223563,AUTHORITY['EPSG','7030']],AUTHORITY['EPSG','6326']],PRIMEM['Greenwich',0,AUTHORITY['EPSG','8901']],UNIT['degree',0.0174532925199433,AUTHORITY['EPSG','9122']],AUTHORITY['EPSG','4326']]"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of crs variable definition
    ####


    # Sub groups
class ProvenanceGrp:
    @staticmethod
    def get_group_path():
        return RootGrp.get_group_path()+"Provenance/"

    def create_group(self, parent_group: nc.Dataset,vlen_type_dict=None,**attributes):
        g = parent_group.createGroup(self.get_group_path())
        if vlen_type_dict is None:
            vlen_type_dict = {}

        #declare vlen types:
        for key, value in vlen_type_dict.items():
            vlen_type = g.createVLType(vlen_type_dict[key], key)
        if "software_name" not in attributes:
            g.software_name = "null"#Name of the software used to generate the dataset.
        if "software_version" not in attributes:
            g.software_version = "null"#Version of the software used to generate the dataset.
        if "history" not in attributes:
            g.history = "null"#Provides an audit trail for modifications to the original data. It should contain a separate line for each modification, with each line beginning with a timestamp and including user name, modification name and modification arguments. for example  2019-09-07T15:50+00Z (John Doe) File conversion by XXX software

        #write attributes passed as argument
        for key, value in attributes.items():
            g.setncattr(key, value)

        return g

    # dimensions names declaration
    FILENAMES_DIM_NAME = "filenames"

    def create_dimension(self, group: nc.Dataset, values: dict):
        """Pass as argument an array of dimension to be created and their values (use None for unlimited dimension)"""
        for dimension_name in values.keys():
            group.createDimension(dimension_name, values[dimension_name])

    # Variables names
    ###
    #source_filenames variable definition
    SOURCE_FILENAMES_VNAME="source_filenames"

    @staticmethod
    def SOURCE_FILENAMES():
        return ProvenanceGrp.get_group_path()+"source_filenames"

    def create_source_filenames(self, group: nc.Dataset, missing_value=None, **attributes):
        """create variable source_filenames"""
        v = group.createVariable(varname="source_filenames", datatype=str, dimensions=("filenames"), fill_value=missing_value)
        if "long_name" not in attributes:
            v.long_name = "Source filenames"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of source_filenames variable definition
    ####

class NavigationGrp:
    @staticmethod
    def get_group_path():
        return RootGrp.get_group_path()+"Navigation/"

    def create_group(self, parent_group: nc.Dataset,vlen_type_dict=None,**attributes):
        g = parent_group.createGroup(self.get_group_path())
        if vlen_type_dict is None:
            vlen_type_dict = {}

        #declare vlen types:
        for key, value in vlen_type_dict.items():
            vlen_type = g.createVLType(vlen_type_dict[key], key)
        if "featureType" not in attributes:
            g.featureType = "trajectory"

        #write attributes passed as argument
        for key, value in attributes.items():
            g.setncattr(key, value)

        return g

    # dimensions names declaration
    TIME_DIM_NAME = "time"

    def create_dimension(self, group: nc.Dataset, values: dict):
        """Pass as argument an array of dimension to be created and their values (use None for unlimited dimension)"""
        for dimension_name in values.keys():
            group.createDimension(dimension_name, values[dimension_name])

    # Coordinate Variables names
    ###
    #time variable definition
    TIME_VNAME="time"

    @staticmethod
    def TIME():
        return NavigationGrp.get_group_path()+"time"

    def create_time(self, group: nc.Dataset, missing_value=None, **attributes):
        """create variable time"""
        v = group.createVariable(varname="time", datatype=np.uint64, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "axis" not in attributes:
            v.axis = "T"
        if "calendar" not in attributes:
            v.calendar = "gregorian"
        if "long_name" not in attributes:
            v.long_name = "Time-stamp of each ping"
        if "standard_name" not in attributes:
            v.standard_name = "time"
        if "units" not in attributes:
            v.units = "nanoseconds since 1970-01-01 00:00:00Z"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of time variable definition
    ####

    # Variables names
    ###
    #point_of_application variable definition
    POINT_OF_APPLICATION_VNAME="point_of_application"

    @staticmethod
    def POINT_OF_APPLICATION():
        return NavigationGrp.get_group_path()+"point_of_application"

    def create_point_of_application(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable point_of_application"""
        v = group.createVariable(varname="point_of_application", datatype=np.float32, dimensions=(), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "x" not in attributes:
            v.x = np.float32(0.0)
        if "y" not in attributes:
            v.y = np.float32(0.0)
        if "z" not in attributes:
            v.z = np.float32(0.0)
        if "description" not in attributes:
            v.description = "All kinematic quantities of this group (Navigation) are expressed at the same platform location, called point of application, by default it refers to the platform reference point."
        if "standard_name" not in attributes:
            v.standard_name = "point_of_application"
        if "long_name" not in attributes:
            v.long_name = "point of application of the kinematic quantities of the Navigation Group."

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of point_of_application variable definition
    ####

    ###
    #latitude variable definition
    LATITUDE_VNAME="latitude"

    @staticmethod
    def LATITUDE():
        return NavigationGrp.get_group_path()+"latitude"

    def create_latitude(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable latitude"""
        v = group.createVariable(varname="latitude", datatype=np.float64, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "valid_range" not in attributes:
            v.valid_range = [-90.0, 90.0]
        if "standard_name" not in attributes:
            v.standard_name = "latitude"
        if "units" not in attributes:
            v.units = "degrees_north"
        if "long_name" not in attributes:
            v.long_name = "latitude"
        if "coordinates" not in attributes:
            v.coordinates = "time latitude longitude"
        if "sdn_parameter_urn" not in attributes:
            v.sdn_parameter_urn = "SDN:P01::ALATZZ01"
        if "sdn_parameter_uri" not in attributes:
            v.sdn_parameter_uri = "https://vocab.nerc.ac.uk/collection/P01/current/ALATZZ01/"
        if "sdn_parameter_name" not in attributes:
            v.sdn_parameter_name = "Latitude north"
        if "sdn_uom_urn" not in attributes:
            v.sdn_uom_urn = "SDN:P06::DEGN"
        if "sdn_uom_name" not in attributes:
            v.sdn_uom_name = "Degrees north"
        if "sdn_uom_uri" not in attributes:
            v.sdn_uom_uri = "https://vocab.nerc.ac.uk/collection/P06/current/DEGN/"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of latitude variable definition
    ####

    ###
    #quality_flag variable definition
    QUALITY_FLAG_VNAME="quality_flag"

    @staticmethod
    def QUALITY_FLAG():
        return NavigationGrp.get_group_path()+"quality_flag"

    def create_quality_flag(self, group: nc.Dataset, missing_value=9, **attributes):
        """create variable quality_flag"""
        v = group.createVariable(varname="quality_flag", datatype=np.byte, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "standard_name" not in attributes:
            v.standard_name = "quality_flag"
        if "long_name" not in attributes:
            v.long_name = "quality flag"
        if "flag_values" not in attributes:
            v.flag_values = "0b,1b,2b,3b,4b,5b,6b,7b,8b,9b"
        if "flag_meanings" not in attributes:
            v.flag_meanings = "no_quality_control good_value probably_good_value probably_bad_value bad_value changed_value value_below_detection value_in_excess interpolated_value missing_value"
        if "coordinates" not in attributes:
            v.coordinates = "time latitude longitude"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of quality_flag variable definition
    ####

    ###
    #longitude variable definition
    LONGITUDE_VNAME="longitude"

    @staticmethod
    def LONGITUDE():
        return NavigationGrp.get_group_path()+"longitude"

    def create_longitude(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable longitude"""
        v = group.createVariable(varname="longitude", datatype=np.float64, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "valid_range" not in attributes:
            v.valid_range = [-180.0, 180.0]
        if "standard_name" not in attributes:
            v.standard_name = "longitude"
        if "units" not in attributes:
            v.units = "degrees_east"
        if "long_name" not in attributes:
            v.long_name = "longitude"
        if "sdn_parameter_urn" not in attributes:
            v.sdn_parameter_urn = "SDN:P01::ALONZZ01"
        if "sdn_parameter_uri" not in attributes:
            v.sdn_parameter_uri = "https://vocab.nerc.ac.uk/collection/P01/current/ALONZZ01/"
        if "sdn_parameter_name" not in attributes:
            v.sdn_parameter_name = "Longitude east"
        if "sdn_uom_urn" not in attributes:
            v.sdn_uom_urn = "SDN:P06::DEGE"
        if "sdn_uom_name" not in attributes:
            v.sdn_uom_name = "Degrees east"
        if "sdn_uom_uri" not in attributes:
            v.sdn_uom_uri = ""

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of longitude variable definition
    ####

    ###
    #heading variable definition
    HEADING_VNAME="heading"

    @staticmethod
    def HEADING():
        return NavigationGrp.get_group_path()+"heading"

    def create_heading(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable heading"""
        v = group.createVariable(varname="heading", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "standard_name" not in attributes:
            v.standard_name = "heading"
        if "units" not in attributes:
            v.units = "degree"
        if "long_name" not in attributes:
            v.long_name = "heading(true)"
        if "coordinates" not in attributes:
            v.coordinates = "time latitude longitude"
        if "sdn_parameter_urn" not in attributes:
            v.sdn_parameter_urn = "SDN:P01::HEADPT01"
        if "sdn_parameter_uri" not in attributes:
            v.sdn_parameter_uri = "https://vocab.nerc.ac.uk/collection/P01/current/HEADPT01/"
        if "sdn_parameter_name" not in attributes:
            v.sdn_parameter_name = "Orientation (horizontal) of measurement platform relative to True North {heading} in the water body by estimation using best available on-board navigation system and algorithm"
        if "sdn_uom_urn" not in attributes:
            v.sdn_uom_urn = "SDN:P06::UAAA"
        if "sdn_uom_name" not in attributes:
            v.sdn_uom_name = "Degrees"
        if "sdn_uom_uri" not in attributes:
            v.sdn_uom_uri = "https://vocab.nerc.ac.uk/collection/P06/current/UAAA/"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of heading variable definition
    ####

    ###
    #heading_rate variable definition
    HEADING_RATE_VNAME="heading_rate"

    @staticmethod
    def HEADING_RATE():
        return NavigationGrp.get_group_path()+"heading_rate"

    def create_heading_rate(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable heading_rate"""
        v = group.createVariable(varname="heading_rate", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "long_name" not in attributes:
            v.long_name = "heading rate"
        if "units" not in attributes:
            v.units = "degree/s"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of heading_rate variable definition
    ####

    ###
    #course_over_ground variable definition
    COURSE_OVER_GROUND_VNAME="course_over_ground"

    @staticmethod
    def COURSE_OVER_GROUND():
        return NavigationGrp.get_group_path()+"course_over_ground"

    def create_course_over_ground(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable course_over_ground"""
        v = group.createVariable(varname="course_over_ground", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "standard_name" not in attributes:
            v.standard_name = "course"
        if "units" not in attributes:
            v.units = "degree"
        if "long_name" not in attributes:
            v.long_name = "course"
        if "coordinates" not in attributes:
            v.coordinates = "time latitude longitude"
        if "sdn_parameter_urn" not in attributes:
            v.sdn_parameter_urn = "SDN:P01::APDAZZ01"
        if "sdn_parameter_uri" not in attributes:
            v.sdn_parameter_uri = "https://vocab.nerc.ac.uk/collection/P01/current/APDAZZ01/"
        if "sdn_parameter_name" not in attributes:
            v.sdn_parameter_name = "Direction of motion of measurement platform relative to ground surface {course made good}"
        if "sdn_uom_urn" not in attributes:
            v.sdn_uom_urn = "SDN:P06::UABB"
        if "sdn_uom_name" not in attributes:
            v.sdn_uom_name = "Degrees True"
        if "sdn_uom_uri" not in attributes:
            v.sdn_uom_uri = "https://vocab.nerc.ac.uk/collection/P06/current/UABB/"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of course_over_ground variable definition
    ####

    ###
    #pitch variable definition
    PITCH_VNAME="pitch"

    @staticmethod
    def PITCH():
        return NavigationGrp.get_group_path()+"pitch"

    def create_pitch(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable pitch"""
        v = group.createVariable(varname="pitch", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "standard_name" not in attributes:
            v.standard_name = "pitch_angle"
        if "units" not in attributes:
            v.units = "arc_degree"
        if "long_name" not in attributes:
            v.long_name = "pitch"
        if "coordinates" not in attributes:
            v.coordinates = "time latitude longitude"
        if "sdn_parameter_urn" not in attributes:
            v.sdn_parameter_urn = "SDN:P01::PTCHGP01"
        if "sdn_parameter_uri" not in attributes:
            v.sdn_parameter_uri = "https://vocab.nerc.ac.uk/collection/P01/current/PTCHGP01/"
        if "sdn_parameter_name" not in attributes:
            v.sdn_parameter_name = "Orientation (pitch) of measurement device by unspecified GPS system"
        if "sdn_uom_urn" not in attributes:
            v.sdn_uom_urn = "SDN:P06::UAAA"
        if "sdn_uom_name" not in attributes:
            v.sdn_uom_name = "Degrees"
        if "sdn_uom_uri" not in attributes:
            v.sdn_uom_uri = "https://vocab.nerc.ac.uk/collection/P06/current/UAAA/"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of pitch variable definition
    ####

    ###
    #pitch_rate variable definition
    PITCH_RATE_VNAME="pitch_rate"

    @staticmethod
    def PITCH_RATE():
        return NavigationGrp.get_group_path()+"pitch_rate"

    def create_pitch_rate(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable pitch_rate"""
        v = group.createVariable(varname="pitch_rate", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "standard_name" not in attributes:
            v.standard_name = "pitch_rate"
        if "units" not in attributes:
            v.units = "degree/s"
        if "long_name" not in attributes:
            v.long_name = "pitch rate"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of pitch_rate variable definition
    ####

    ###
    #roll variable definition
    ROLL_VNAME="roll"

    @staticmethod
    def ROLL():
        return NavigationGrp.get_group_path()+"roll"

    def create_roll(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable roll"""
        v = group.createVariable(varname="roll", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "standard_name" not in attributes:
            v.standard_name = "roll_angle"
        if "units" not in attributes:
            v.units = "arc_degree"
        if "long_name" not in attributes:
            v.long_name = "roll"
        if "coordinates" not in attributes:
            v.coordinates = "time latitude longitude"
        if "sdn_parameter_urn" not in attributes:
            v.sdn_parameter_urn = "SDN:P01::ROLLPT01"
        if "sdn_parameter_uri" not in attributes:
            v.sdn_parameter_uri = "https://vocab.nerc.ac.uk/collection/P01/current/ROLLPT01/"
        if "sdn_parameter_name" not in attributes:
            v.sdn_parameter_name = "Orientation (roll) of measurement platform in the water body by estimation using best available on-board navigation system and algorithm"
        if "sdn_uom_urn" not in attributes:
            v.sdn_uom_urn = "SDN:P06::UAAA"
        if "sdn_uom_name" not in attributes:
            v.sdn_uom_name = "Degrees"
        if "sdn_uom_uri" not in attributes:
            v.sdn_uom_uri = "https://vocab.nerc.ac.uk/collection/P06/current/UAAA/"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of roll variable definition
    ####

    ###
    #roll_rate variable definition
    ROLL_RATE_VNAME="roll_rate"

    @staticmethod
    def ROLL_RATE():
        return NavigationGrp.get_group_path()+"roll_rate"

    def create_roll_rate(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable roll_rate"""
        v = group.createVariable(varname="roll_rate", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "standard_name" not in attributes:
            v.standard_name = "roll_rate"
        if "units" not in attributes:
            v.units = "degree/s"
        if "long_name" not in attributes:
            v.long_name = "roll rate"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of roll_rate variable definition
    ####

    ###
    #speed_over_ground variable definition
    SPEED_OVER_GROUND_VNAME="speed_over_ground"

    @staticmethod
    def SPEED_OVER_GROUND():
        return NavigationGrp.get_group_path()+"speed_over_ground"

    def create_speed_over_ground(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable speed_over_ground"""
        v = group.createVariable(varname="speed_over_ground", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "standard_name" not in attributes:
            v.standard_name = "speed_wrt_ground"
        if "units" not in attributes:
            v.units = "m/s"
        if "long_name" not in attributes:
            v.long_name = "speed over ground"
        if "valid_min" not in attributes:
            v.valid_min = np.float32(0.0)
        if "coordinates" not in attributes:
            v.coordinates = "time latitude longitude"
        if "sdn_parameter_urn" not in attributes:
            v.sdn_parameter_urn = "SDN:P01::APSAZZ01"
        if "sdn_parameter_uri" not in attributes:
            v.sdn_parameter_uri = "https://vocab.nerc.ac.uk/collection/P01/current/APSAZZ01/"
        if "sdn_parameter_name" not in attributes:
            v.sdn_parameter_name = "Speed of measurement platform relative to ground surface {speed over ground}"
        if "sdn_uom_urn" not in attributes:
            v.sdn_uom_urn = "SDN:P06::UVAA"
        if "sdn_uom_name" not in attributes:
            v.sdn_uom_name = "Metres per second"
        if "sdn_uom_uri" not in attributes:
            v.sdn_uom_uri = "https://vocab.nerc.ac.uk/collection/P06/current/UVAA/"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of speed_over_ground variable definition
    ####

    ###
    #speed_relative variable definition
    SPEED_RELATIVE_VNAME="speed_relative"

    @staticmethod
    def SPEED_RELATIVE():
        return NavigationGrp.get_group_path()+"speed_relative"

    def create_speed_relative(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable speed_relative"""
        v = group.createVariable(varname="speed_relative", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "long_name" not in attributes:
            v.long_name = "speed relative to water"
        if "standard_name" not in attributes:
            v.standard_name = "platform_speed_wrt_seawater"
        if "units" not in attributes:
            v.units = "m/s"
        if "valid_min" not in attributes:
            v.valid_min = np.float32(0.0)
        if "coordinates" not in attributes:
            v.coordinates = "time latitude longitude"
        if "sdn_parameter_urn" not in attributes:
            v.sdn_parameter_urn = "SDN:S29::PE001314"
        if "sdn_parameter_uri" not in attributes:
            v.sdn_parameter_uri = "https://vocab.nerc.ac.uk/collection/S29/current/PE001314/"
        if "sdn_uom_urn" not in attributes:
            v.sdn_uom_urn = "SDN:P06::UVAA"
        if "sdn_uom_name" not in attributes:
            v.sdn_uom_name = "Metres per second"
        if "sdn_uom_uri" not in attributes:
            v.sdn_uom_uri = "https://vocab.nerc.ac.uk/collection/P06/current/UVAA/"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of speed_relative variable definition
    ####

    ###
    #height_above_reference_ellipsoid variable definition
    HEIGHT_ABOVE_REFERENCE_ELLIPSOID_VNAME="height_above_reference_ellipsoid"

    @staticmethod
    def HEIGHT_ABOVE_REFERENCE_ELLIPSOID():
        return NavigationGrp.get_group_path()+"height_above_reference_ellipsoid"

    def create_height_above_reference_ellipsoid(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable height_above_reference_ellipsoid"""
        v = group.createVariable(varname="height_above_reference_ellipsoid", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "standard_name" not in attributes:
            v.standard_name = "height_above_reference_ellipsoid"
        if "units" not in attributes:
            v.units = "m"
        if "long_name" not in attributes:
            v.long_name = "height above reference ellipsoid"
        if "coordinates" not in attributes:
            v.coordinates = "time latitude longitude"
        if "sdn_parameter_urn" not in attributes:
            v.sdn_parameter_urn = "SDN:P02::AHGT"
        if "sdn_parameter_uri" not in attributes:
            v.sdn_parameter_uri = "https://vocab.nerc.ac.uk/collection/P02/current/AHGT/"
        if "sdn_parameter_name" not in attributes:
            v.sdn_parameter_name = "Vertical spatial coordinates"
        if "sdn_uom_urn" not in attributes:
            v.sdn_uom_urn = "SDN:P06::ULAA"
        if "sdn_uom_name" not in attributes:
            v.sdn_uom_name = "Metres"
        if "sdn_uom_uri" not in attributes:
            v.sdn_uom_uri = "https://vocab.nerc.ac.uk/collection/P06/current/ULAA/"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of height_above_reference_ellipsoid variable definition
    ####

    ###
    #position_quality_indicator variable definition
    POSITION_QUALITY_INDICATOR_VNAME="position_quality_indicator"

    @staticmethod
    def POSITION_QUALITY_INDICATOR():
        return NavigationGrp.get_group_path()+"position_quality_indicator"

    def create_position_quality_indicator(self, group: nc.Dataset, missing_value=None, **attributes):
        """create variable position_quality_indicator"""
        v = group.createVariable(varname="position_quality_indicator", datatype=np.byte, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "long_name" not in attributes:
            v.long_name = "Sensor quality indicator"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of position_quality_indicator variable definition
    ####

    ###
    #vertical_offset variable definition
    VERTICAL_OFFSET_VNAME="vertical_offset"

    @staticmethod
    def VERTICAL_OFFSET():
        return NavigationGrp.get_group_path()+"vertical_offset"

    def create_vertical_offset(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable vertical_offset"""
        v = group.createVariable(varname="vertical_offset", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "units" not in attributes:
            v.units = "m"
        if "long_name" not in attributes:
            v.long_name = "vertical offset referred to sea surface level"
        if "sdn_parameter_urn" not in attributes:
            v.sdn_parameter_urn = "SDN:P01::ADEPZZ01"
        if "sdn_parameter_uri" not in attributes:
            v.sdn_parameter_uri = "https://vocab.nerc.ac.uk/collection/P01/current/ADEPZZ01/"
        if "sdn_parameter_name" not in attributes:
            v.sdn_parameter_name = "Depth (spatial coordinate) relative to water surface in the water body"
        if "sdn_uom_urn" not in attributes:
            v.sdn_uom_urn = "SDN:P06::ULAA"
        if "sdn_uom_name" not in attributes:
            v.sdn_uom_name = "Metres"
        if "sdn_uom_uri" not in attributes:
            v.sdn_uom_uri = "https://vocab.nerc.ac.uk/collection/P06/current/ULAA/"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of vertical_offset variable definition
    ####

    ###
    #true_vertical_offset variable definition
    TRUE_VERTICAL_OFFSET_VNAME="true_vertical_offset"

    @staticmethod
    def TRUE_VERTICAL_OFFSET():
        return NavigationGrp.get_group_path()+"true_vertical_offset"

    def create_true_vertical_offset(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable true_vertical_offset"""
        v = group.createVariable(varname="true_vertical_offset", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "units" not in attributes:
            v.units = "m"
        if "long_name" not in attributes:
            v.long_name = "true vertical offset referred to sea surface level"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of true_vertical_offset variable definition
    ####

    ###
    #velocity_north variable definition
    VELOCITY_NORTH_VNAME="velocity_north"

    @staticmethod
    def VELOCITY_NORTH():
        return NavigationGrp.get_group_path()+"velocity_north"

    def create_velocity_north(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable velocity_north"""
        v = group.createVariable(varname="velocity_north", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "long_name" not in attributes:
            v.long_name = "north component of the platform velocity"
        if "standard_name" not in attributes:
            v.standard_name = "velocity_north"
        if "units" not in attributes:
            v.units = "m/s"
        if "coordinates" not in attributes:
            v.coordinates = "time latitude longitude"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of velocity_north variable definition
    ####

    ###
    #velocity_east variable definition
    VELOCITY_EAST_VNAME="velocity_east"

    @staticmethod
    def VELOCITY_EAST():
        return NavigationGrp.get_group_path()+"velocity_east"

    def create_velocity_east(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable velocity_east"""
        v = group.createVariable(varname="velocity_east", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "long_name" not in attributes:
            v.long_name = "east component of the platform velocity"
        if "standard_name" not in attributes:
            v.standard_name = "velocity_east"
        if "units" not in attributes:
            v.units = "m/s"
        if "coordinates" not in attributes:
            v.coordinates = "time latitude longitude"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of velocity_east variable definition
    ####

    ###
    #velocity_down variable definition
    VELOCITY_DOWN_VNAME="velocity_down"

    @staticmethod
    def VELOCITY_DOWN():
        return NavigationGrp.get_group_path()+"velocity_down"

    def create_velocity_down(self, group: nc.Dataset, missing_value=np.nan, **attributes):
        """create variable velocity_down"""
        v = group.createVariable(varname="velocity_down", datatype=np.float32, dimensions=("time"), fill_value=missing_value, compression=DEFAULT_COMPRESSION_LIB)
        if "long_name" not in attributes:
            v.long_name = "down component of the platform velocity"
        if "standard_name" not in attributes:
            v.standard_name = "velocity_down"
        if "units" not in attributes:
            v.units = "m/s"
        if "coordinates" not in attributes:
            v.coordinates = "time latitude longitude"

        #write attributes passed as argument
        for key, value in attributes.items():
            v.setncattr(key, value)
        return v

    #End of velocity_down variable definition
    ####

