"""Package for legacy nvi file format
Legacy format is the old nvi file format defined by Caraibes software, it has an .nvi extension
"""
