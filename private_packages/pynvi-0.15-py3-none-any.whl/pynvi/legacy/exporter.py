import abc
import logging
from abc import ABC
from datetime import datetime
from enum import Enum
from os import path, PathLike
from typing import List, Tuple

import numpy as np
from osgeo import gdal, ogr, osr
import pandas as pd

from pynvi.legacy import nvi_driver
from pynvi.utils import path_utils

# Constant fields
FILE_FIELD = "FicData"
PROFILE_FIELD = "Profil"
START_DATE_FIELD = "DateDeb"
END_DATE_FIELD = "DateFin"
START_TIME_FIELD = "HeureDeb"
END_TIME_FIELD = "HeureFin"
START_LAT_FIELD = "LatDeb"
START_LON_FIELD = "LonDeb"
END_LAT_FIELD = "LatFin"
END_LON_FIELD = "LonFin"
CAMPAIGN_NAME = "Campagne"
CAMPAIGN_NUM = "NumCamp"
NAVIGATION = "Navigation"
TOOL = "Outil"

LAT_FIELD = "Latitude"
LON_FIELD = "Longitude"
DATE_FIELD = "Date"
TIME_FIELD = "Heure"

gdal.UseExceptions()


# pylint:disable=broad-exception-raised


class ShapeExportType(Enum):
    POINT = 0
    POLYLINE = 1


class Convert2Shp(ABC):
    """
    This class provides methods to convert netcdf navigation files to shape files.
    """

    def __init__(
        self,
        input_files: List[PathLike],
        output_file: PathLike,
        overwrite: bool = False,
        campaign: str = None,
        campaign_number: str = None,
        navigation: str = None,
        tool: str = None,
        export_type: ShapeExportType = ShapeExportType.POLYLINE,
        logger=None,
    ):
        """
        Initialize parameters.
        """
        self.input_files = input_files
        self.output_file = output_file
        self.added_const_fields = {}
        if campaign is not None:
            self.added_const_fields[CAMPAIGN_NAME] = campaign
        if campaign_number is not None:
            self.added_const_fields[CAMPAIGN_NUM] = campaign_number
        if navigation is not None:
            self.added_const_fields[NAVIGATION] = navigation
        if tool is not None:
            self.added_const_fields[TOOL] = tool
        self.export_type = export_type

        self.overwrite = overwrite
        if logger is None:
            self.logger = logging.getLogger(self.__class__.__name__)
        else:
            self.logger = logger

    @abc.abstractmethod
    def get_navigation_data_values(
        self, filename
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, datetime, datetime]:
        """This function retrieves valid navigation data from the given filename
        Return :
            longitudes, latitudes values as np.ndarray,
            validity flag as a np.ndarray of boolean,
            times as np.ndarray of datetime64[ns],
            start,stop dates as datetime
        """

    # pylint: disable=too-many-nested-blocks
    def __call__(self):
        """
        Main method : converts NVI/MBG to a shape file.
        """

        # shape file driver
        shp_driver = ogr.GetDriverByName("ESRI Shapefile")
        layer_mapper = {
            ShapeExportType.POINT: ogr.wkbPoint,
            ShapeExportType.POLYLINE: ogr.wkbLineString,
        }
        # data source
        if path.exists(self.output_file):
            if self.overwrite:
                shp_driver.DeleteDataSource(self.output_file)
            else:
                self.logger.error(
                    f"Error: file already exists: {str(self.output_file)}"
                )
                raise IOError(f"Error: file already exists: {str(self.output_file)}")

        try:
            data_source = shp_driver.CreateDataSource(self.output_file)

            if data_source is None:
                self.logger.error(f"Error while opening file {str(self.output_file)}")
                raise IOError(f"Error while opening file {str(self.output_file)}")

            # spatial reference, WGS84
            srs = osr.SpatialReference()
            srs.ImportFromEPSG(4326)

            # creation layer
            layer_name = path_utils.basename_of_fname(self.output_file)
            layer = data_source.CreateLayer("NAV", srs, layer_mapper[self.export_type])

            if layer is None:
                msg = f"Could not create layer {layer_name}"
                raise Exception(msg)

            # create fields
            layer.CreateField(ogr.FieldDefn(PROFILE_FIELD, ogr.OFTString))
            layer.CreateField(ogr.FieldDefn(FILE_FIELD, ogr.OFTString))
            if self.export_type == ShapeExportType.POLYLINE:
                layer.CreateField(ogr.FieldDefn(START_DATE_FIELD, ogr.OFTString))
                layer.CreateField(ogr.FieldDefn(END_DATE_FIELD, ogr.OFTString))
                layer.CreateField(ogr.FieldDefn(START_TIME_FIELD, ogr.OFTString))
                layer.CreateField(ogr.FieldDefn(END_TIME_FIELD, ogr.OFTString))
                layer.CreateField(ogr.FieldDefn(START_LON_FIELD, ogr.OFTReal))
                layer.CreateField(ogr.FieldDefn(START_LAT_FIELD, ogr.OFTReal))
                layer.CreateField(ogr.FieldDefn(END_LON_FIELD, ogr.OFTReal))
                layer.CreateField(ogr.FieldDefn(END_LAT_FIELD, ogr.OFTReal))
            else:
                layer.CreateField(ogr.FieldDefn(LAT_FIELD, ogr.OFTReal))
                layer.CreateField(ogr.FieldDefn(LON_FIELD, ogr.OFTReal))
                layer.CreateField(ogr.FieldDefn(DATE_FIELD, ogr.OFTString))
                layer.CreateField(ogr.FieldDefn(TIME_FIELD, ogr.OFTString))

            # create constant fields
            layer.CreateField(ogr.FieldDefn(CAMPAIGN_NUM, ogr.OFTString))
            layer.CreateField(ogr.FieldDefn(CAMPAIGN_NAME, ogr.OFTString))
            layer.CreateField(ogr.FieldDefn(NAVIGATION, ogr.OFTString))
            layer.CreateField(ogr.FieldDefn(TOOL, ogr.OFTString))

            # log constant fields
            self.logger.info(f"Exporting to shape file : {self.output_file}")
            for field_name, field_value in self.added_const_fields.items():
                self.logger.info(f"{field_name}:{str(field_value)}")

            feature = ogr.Feature(layer.GetLayerDefn())
            # sets constant fields
            for field_name, field_value in self.added_const_fields.items():
                feature.SetField(field_name, str(field_value))

            for filein in self.input_files:
                # fill polyline and fields (abstract method specific for each input file type)
                (
                    lon,
                    lat,
                    validity,
                    time,
                    start_date,
                    end_date,
                ) = self.get_navigation_data_values(filename=filein)

                # Populate polyline
                if len(lat) > 1:
                    feature.SetField(FILE_FIELD, path.basename(filein))
                    feature.SetField(
                        # profile is the first part of the filename before the first underscore
                        PROFILE_FIELD,
                        path_utils.basename_of_fname(filein).split("_")[0],
                    )
                    if self.export_type == ShapeExportType.POLYLINE:
                        feature.SetField(
                            START_DATE_FIELD, start_date.strftime("%d/%m/%Y")
                        )
                        feature.SetField(END_DATE_FIELD, end_date.strftime("%d/%m/%Y"))
                        feature.SetField(
                            START_TIME_FIELD, start_date.strftime("%H:%M:%S")
                        )
                        feature.SetField(END_TIME_FIELD, end_date.strftime("%H:%M:%S"))
                        geometry = ogr.Geometry(ogr.wkbLineString)
                        for lg, lt, flag in zip(lon, lat, validity):
                            # keep only valid points
                            valid_values = (
                                not np.isnan(lg)
                                and not np.isnan(lt)
                                and not (lg is np.ma.masked)
                                and not (lt is np.ma.masked)
                            )  # flag value shoud be enough but in some cases data is invalid even if point are marked as valid
                            if flag and valid_values:
                                geometry.AddPoint(lg, lt)
                        # set fields value
                        count = geometry.GetPointCount()
                        feature.SetField(START_LON_FIELD, geometry.GetPoint(0)[0])
                        feature.SetField(START_LAT_FIELD, geometry.GetPoint(0)[1])
                        feature.SetField(END_LON_FIELD, geometry.GetPoint(count - 1)[0])
                        feature.SetField(END_LAT_FIELD, geometry.GetPoint(count - 1)[1])
                        self.logger.info(
                            f"Create {filein} geometry : {geometry.GetPointCount()} points"
                        )
                        feature.SetGeometry(geometry)
                    else:  # ShapeExportType.POINT
                        count = 0
                        for lg, lt, flag, dt64 in zip(lon, lat, validity, time):
                            valid_values = (
                                not np.isnan(lg)
                                and not np.isnan(lt)
                                and not (lg is np.ma.masked)
                                and not (lt is np.ma.masked)
                            )  # flag value shoud be enough but in some cases data is invalid even if point are marked as valid
                            if flag and valid_values:
                                dt = pd.to_datetime(np.datetime64(dt64, "ns"))
                                point = ogr.Geometry(ogr.wkbPoint)
                                point.AddPoint(lg, lt)
                                count += 1
                                feature.SetField(DATE_FIELD, dt.strftime("%d/%m/%Y"))
                                feature.SetField(
                                    TIME_FIELD, dt.strftime("%H:%M:%S.%f")[:-3]
                                )  # remove last 3 digits to have milliseconds
                                feature.SetField(LON_FIELD, point.GetPoint(0)[0])
                                feature.SetField(LAT_FIELD, point.GetPoint(0)[1])
                                feature.SetGeometry(point)
                                layer.CreateFeature(feature)
                        self.logger.info(f"Create {filein} geometry : {count} points")
                else:
                    self.logger.warning(f"Skip file {filein} having {len(lat)} points")

                # Create the feature in the layer (shape file)
                if self.export_type == ShapeExportType.POLYLINE:
                    layer.CreateFeature(feature)
        finally:
            data_source = None  # should close the files


class ConvertNvi2Shp(Convert2Shp):
    def get_navigation_data_values(
        self, filename
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, datetime, datetime]:
        """
        Reads an NVI file, and fill the provided polyline and feature.
        """
        print("Input file (nvi) :", filename)
        with nvi_driver.nc_open(filename) as nvi:
            lon = nvi.get_longitudes()
            lat = nvi.get_latitudes()
            validity_flag = nvi.get_validities()
            time = nvi.get_times()
            start_date = nvi.get_start_date()
            end_date = nvi.get_end_date()

            return (lon, lat, validity_flag, time, start_date, end_date)
