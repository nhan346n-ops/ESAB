"""Functions helping to work with filenames"""

import os
from typing import Tuple


def splitext_of_fname(fname: str) -> Tuple[str, str]:
    """
    >>> splitext_of_fname('./a/data.nvi')
    ('./a/data', 'nvi')
    >>> splitext_of_fname('./a/data.nvi.nc')
    ('./a/data', 'nvi.nc')
    """
    fname, last_ext = os.path.splitext(fname)
    exts = [last_ext]
    while last_ext:
        fname, last_ext = os.path.splitext(fname)
        exts.append(last_ext)
    ext = "".join(reversed(exts[:-1])).lstrip(".")
    return fname, ext


def basename_of_fname(fname: str) -> str:
    """
    >>> basename_of_fname('./a/data.nvi')
    'data'
    >>> basename_of_fname('./a/data.nvi.nc')
    'data'
    """
    return os.path.split(splitext_of_fname(fname)[0])[1]


def ext_of_fname(fname: str) -> str:
    """
    >>> ext_of_fname('./a/data.nvi')
    'nvi'
    >>> ext_of_fname('./a/data.nvi.nc')
    'nvi.nc'
    """
    return splitext_of_fname(fname)[1]
